import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const followUser = mutation({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const currentUserId = await getAuthUserId(ctx);
    if (!currentUserId) throw new Error("Not authenticated");
    if (currentUserId === args.userId) throw new Error("Cannot follow yourself");

    const existingFollow = await ctx.db
      .query("follows")
      .withIndex("by_follower", (q) => q.eq("followerId", currentUserId))
      .filter((q) => q.eq(q.field("followingId"), args.userId))
      .unique();

    if (existingFollow) throw new Error("Already following or request pending");

    await ctx.db.insert("follows", {
      followerId: currentUserId,
      followingId: args.userId,
      status: "pending",
    });

    // Create notification
    await ctx.db.insert("notifications", {
      userId: args.userId,
      type: "follow_request",
      fromUserId: currentUserId,
      isRead: false,
    });
  },
});

export const acceptFollowRequest = mutation({
  args: { followerId: v.id("users") },
  handler: async (ctx, args) => {
    const currentUserId = await getAuthUserId(ctx);
    if (!currentUserId) throw new Error("Not authenticated");

    const followRequest = await ctx.db
      .query("follows")
      .withIndex("by_follower", (q) => q.eq("followerId", args.followerId))
      .filter((q) => q.eq(q.field("followingId"), currentUserId))
      .unique();

    if (!followRequest || followRequest.status !== "pending") {
      throw new Error("Follow request not found");
    }

    await ctx.db.patch(followRequest._id, { status: "accepted" });

    // Create notification
    await ctx.db.insert("notifications", {
      userId: args.followerId,
      type: "follow_accepted",
      fromUserId: currentUserId,
      isRead: false,
    });
  },
});

export const unfollowUser = mutation({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const currentUserId = await getAuthUserId(ctx);
    if (!currentUserId) throw new Error("Not authenticated");

    const follow = await ctx.db
      .query("follows")
      .withIndex("by_follower", (q) => q.eq("followerId", currentUserId))
      .filter((q) => q.eq(q.field("followingId"), args.userId))
      .unique();

    if (follow) {
      await ctx.db.delete(follow._id);
    }
  },
});

export const getFollowers = query({
  args: { userId: v.optional(v.id("users")) },
  handler: async (ctx, args) => {
    const currentUserId = await getAuthUserId(ctx);
    const targetUserId = args.userId || currentUserId;
    if (!targetUserId) return [];

    const followers = await ctx.db
      .query("follows")
      .withIndex("by_following", (q) => q.eq("followingId", targetUserId))
      .filter((q) => q.eq(q.field("status"), "accepted"))
      .collect();

    const followerProfiles = await Promise.all(
      followers.map(async (follow) => {
        const profile = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", follow.followerId))
          .unique();

        const avatarUrl = profile?.avatar ? await ctx.storage.getUrl(profile.avatar) : null;

        return profile ? {
          ...profile,
          avatarUrl,
        } : null;
      })
    );

    return followerProfiles.filter(Boolean);
  },
});

export const getFollowing = query({
  args: { userId: v.optional(v.id("users")) },
  handler: async (ctx, args) => {
    const currentUserId = await getAuthUserId(ctx);
    const targetUserId = args.userId || currentUserId;
    if (!targetUserId) return [];

    const following = await ctx.db
      .query("follows")
      .withIndex("by_follower", (q) => q.eq("followerId", targetUserId))
      .filter((q) => q.eq(q.field("status"), "accepted"))
      .collect();

    const followingProfiles = await Promise.all(
      following.map(async (follow) => {
        const profile = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", follow.followingId))
          .unique();

        const avatarUrl = profile?.avatar ? await ctx.storage.getUrl(profile.avatar) : null;

        return profile ? {
          ...profile,
          avatarUrl,
        } : null;
      })
    );

    return followingProfiles.filter(Boolean);
  },
});

export const getFollowStatus = query({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const currentUserId = await getAuthUserId(ctx);
    if (!currentUserId) return "not_following";

    const follow = await ctx.db
      .query("follows")
      .withIndex("by_follower", (q) => q.eq("followerId", currentUserId))
      .filter((q) => q.eq(q.field("followingId"), args.userId))
      .unique();

    if (!follow) return "not_following";
    return follow.status;
  },
});
