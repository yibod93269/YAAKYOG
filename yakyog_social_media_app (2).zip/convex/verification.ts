import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

async function checkIsAdminOrOwner(ctx: any, userId: string) {
  const user = await ctx.db.get(userId);
  const profile = await ctx.db
    .query("profiles")
    .withIndex("by_user", (q: any) => q.eq("userId", userId))
    .unique();
  
  return user?.email === "mstrbystbyalrbyt@gmail.com" || profile?.role === "admin";
}

export const requestVerification = mutation({
  args: {
    reason: v.optional(v.string()),
    documents: v.optional(v.array(v.id("_storage"))),
    socialLinks: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Check if user already has a pending or approved request
    const existingRequest = await ctx.db
      .query("verificationRequests")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => 
        q.or(
          q.eq(q.field("status"), "pending"),
          q.eq(q.field("status"), "approved")
        )
      )
      .unique();

    if (existingRequest) {
      if (existingRequest.status === "approved") {
        throw new Error("You are already verified");
      }
      throw new Error("You already have a pending verification request");
    }

    return await ctx.db.insert("verificationRequests", {
      userId,
      status: "pending",
      reason: args.reason,
      documents: args.documents || [],
      socialLinks: args.socialLinks || [],
    });
  },
});

export const getVerificationStatus = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const request = await ctx.db
      .query("verificationRequests")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .first();

    return request;
  },
});

export const getPendingVerifications = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId || !(await checkIsAdminOrOwner(ctx, userId))) {
      throw new Error("Unauthorized");
    }

    const requests = await ctx.db
      .query("verificationRequests")
      .withIndex("by_status", (q) => q.eq("status", "pending"))
      .order("desc")
      .collect();

    // Enrich with user data
    const enrichedRequests = await Promise.all(
      requests.map(async (request) => {
        const profile = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", request.userId))
          .unique();

        const user = await ctx.db.get(request.userId);
        const avatarUrl = profile?.avatar ? await ctx.storage.getUrl(profile.avatar) : null;

        // Get document URLs
        const documentUrls = await Promise.all(
          (request.documents || []).map(async (docId) => {
            const url = await ctx.storage.getUrl(docId);
            return { id: docId, url };
          })
        );

        return {
          ...request,
          user: profile ? {
            ...profile,
            email: user?.email,
            avatarUrl,
          } : null,
          documentUrls,
        };
      })
    );

    return enrichedRequests;
  },
});

export const approveVerification = mutation({
  args: { 
    requestId: v.id("verificationRequests"),
    adminNote: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const adminId = await getAuthUserId(ctx);
    if (!adminId || !(await checkIsAdminOrOwner(ctx, adminId))) {
      throw new Error("Unauthorized");
    }

    const request = await ctx.db.get(args.requestId);
    if (!request) throw new Error("Request not found");

    // Update request status
    await ctx.db.patch(args.requestId, {
      status: "approved",
      reviewedBy: adminId,
      reviewedAt: Date.now(),
      adminNote: args.adminNote,
    });

    // Update user profile to verified
    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", request.userId))
      .unique();

    if (profile) {
      await ctx.db.patch(profile._id, {
        isVerified: true,
        verifiedAt: Date.now(),
        verifiedBy: adminId,
      });
    }

    // Create notification for user
    await ctx.db.insert("notifications", {
      userId: request.userId,
      type: "verification_approved",
      fromUserId: adminId,
      isRead: false,
      message: "تم قبول طلب التوثيق الخاص بك! لديك الآن العلامة الزرقاء.",
    });

    // Log the action
    await ctx.db.insert("auditLogs", {
      action: "approve_verification",
      actorId: adminId,
      targetId: request.userId,
      details: `Verification approved. Note: ${args.adminNote || "No note"}`,
    });
  },
});

export const rejectVerification = mutation({
  args: { 
    requestId: v.id("verificationRequests"),
    reason: v.string(),
  },
  handler: async (ctx, args) => {
    const adminId = await getAuthUserId(ctx);
    if (!adminId || !(await checkIsAdminOrOwner(ctx, adminId))) {
      throw new Error("Unauthorized");
    }

    const request = await ctx.db.get(args.requestId);
    if (!request) throw new Error("Request not found");

    // Update request status
    await ctx.db.patch(args.requestId, {
      status: "rejected",
      reviewedBy: adminId,
      reviewedAt: Date.now(),
      rejectionReason: args.reason,
    });

    // Create notification for user
    await ctx.db.insert("notifications", {
      userId: request.userId,
      type: "verification_rejected",
      fromUserId: adminId,
      isRead: false,
      message: `تم رفض طلب التوثيق: ${args.reason}`,
    });

    // Log the action
    await ctx.db.insert("auditLogs", {
      action: "reject_verification",
      actorId: adminId,
      targetId: request.userId,
      details: `Verification rejected. Reason: ${args.reason}`,
    });
  },
});

export const getAllVerifications = query({
  args: {
    status: v.optional(v.union(v.literal("pending"), v.literal("approved"), v.literal("rejected"))),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId || !(await checkIsAdminOrOwner(ctx, userId))) {
      throw new Error("Unauthorized");
    }

    let requests;
    
    if (args.status) {
      requests = await ctx.db
        .query("verificationRequests")
        .withIndex("by_status", (q: any) => q.eq("status", args.status))
        .order("desc")
        .collect();
    } else {
      requests = await ctx.db
        .query("verificationRequests")
        .order("desc")
        .collect();
    }

    // Enrich with user data
    const enrichedRequests = await Promise.all(
      requests.map(async (request) => {
        const profile = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", request.userId))
          .unique();

        const user = await ctx.db.get(request.userId);
        const avatarUrl = profile?.avatar ? await ctx.storage.getUrl(profile.avatar) : null;

        // Get reviewer name if reviewed
        let reviewerName = null;
        if (request.reviewedBy) {
          const reviewerProfile = await ctx.db
            .query("profiles")
            .withIndex("by_user", (q: any) => q.eq("userId", request.reviewedBy))
            .unique();
          reviewerName = reviewerProfile ? `${reviewerProfile.firstName} ${reviewerProfile.lastName}` : "Unknown";
        }

        return {
          ...request,
          user: profile ? {
            ...profile,
            email: user?.email,
            avatarUrl,
          } : null,
          reviewerName,
        };
      })
    );

    return enrichedRequests;
  },
});
