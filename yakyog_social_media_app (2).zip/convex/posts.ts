import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createPost = mutation({
  args: {
    content: v.string(),
    type: v.union(v.literal("text"), v.literal("image"), v.literal("video"), v.literal("story"), v.literal("yogo")),
    mediaId: v.optional(v.id("_storage")),
    privacy: v.union(v.literal("public"), v.literal("friends")),
    isYogo: v.optional(v.boolean()),
    yogoType: v.optional(v.union(v.literal("public"), v.literal("friends"))),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const expiresAt = args.type === "story" ? Date.now() + 24 * 60 * 60 * 1000 : undefined;

    return await ctx.db.insert("posts", {
      authorId: userId,
      content: args.content,
      type: args.type,
      mediaId: args.mediaId,
      likes: [],
      shares: [],
      viewers: [],
      isStory: args.type === "story",
      expiresAt,
      privacy: args.privacy,
      isYogo: args.isYogo || false,
      yogoType: args.yogoType,
    });
  },
});

export const deletePost = mutation({
  args: { postId: v.id("posts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const post = await ctx.db.get(args.postId);
    if (!post) throw new Error("Post not found");

    // Check if user owns the post or is admin
    const isAdmin = await checkIsAdmin(ctx, userId);
    if (post.authorId !== userId && !isAdmin) {
      throw new Error("Not authorized to delete this post");
    }

    await ctx.db.delete(args.postId);
  },
});

export const sharePost = mutation({
  args: { postId: v.id("posts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const post = await ctx.db.get(args.postId);
    if (!post) throw new Error("Post not found");

    const shares = post.shares || [];
    if (!shares.includes(userId)) {
      shares.push(userId);
      await ctx.db.patch(args.postId, { shares });

      // Create notification for post author
      if (post.authorId !== userId) {
        await ctx.db.insert("notifications", {
          userId: post.authorId,
          type: "post_share",
          fromUserId: userId,
          postId: args.postId,
          isRead: false,
        });
      }
    }
  },
});

export const likePost = mutation({
  args: { postId: v.id("posts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const post = await ctx.db.get(args.postId);
    if (!post) throw new Error("Post not found");

    const likes = [...post.likes];
    const likeIndex = likes.indexOf(userId);

    if (likeIndex === -1) {
      likes.push(userId);
      
      // Create notification for post author
      if (post.authorId !== userId) {
        const notificationType = post.isStory ? "story_like" : post.isYogo ? "yogo_like" : "like";
        await ctx.db.insert("notifications", {
          userId: post.authorId,
          type: notificationType,
          fromUserId: userId,
          postId: args.postId,
          isRead: false,
        });
      }
    } else {
      likes.splice(likeIndex, 1);
    }

    await ctx.db.patch(args.postId, { likes });
  },
});

export const viewStory = mutation({
  args: { postId: v.id("posts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const post = await ctx.db.get(args.postId);
    if (!post || !post.isStory) throw new Error("Story not found");

    const viewers = post.viewers || [];
    if (!viewers.includes(userId)) {
      viewers.push(userId);
      await ctx.db.patch(args.postId, { viewers });
    }
  },
});

export const getFeed = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    // Get user's following list
    const following = await ctx.db
      .query("follows")
      .withIndex("by_follower", (q) => q.eq("followerId", userId))
      .filter((q) => q.eq(q.field("status"), "accepted"))
      .collect();

    const followingIds = following.map(f => f.followingId);
    followingIds.push(userId); // Include user's own posts

    // Get all posts from followed users and own posts
    const allPosts = await ctx.db.query("posts").collect();
    const feedPosts = allPosts.filter(post => 
      followingIds.includes(post.authorId) && 
      !post.isStory &&
      (post.privacy === "public" || 
       (post.privacy === "friends" && followingIds.includes(post.authorId)))
    );

    // Sort by creation time (newest first)
    feedPosts.sort((a, b) => b._creationTime - a._creationTime);

    // Enrich posts with author info and media URLs
    const enrichedPosts = await Promise.all(
      feedPosts.slice(0, 20).map(async (post) => {
        const author = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", post.authorId))
          .unique();

        const mediaUrl = post.mediaId ? await ctx.storage.getUrl(post.mediaId) : null;
        const authorAvatarUrl = author?.avatar ? await ctx.storage.getUrl(author.avatar) : null;

        return {
          ...post,
          author: author ? {
            ...author,
            avatarUrl: authorAvatarUrl,
          } : null,
          mediaUrl,
        };
      })
    );

    return enrichedPosts;
  },
});

export const getStories = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    // Get user's following list
    const following = await ctx.db
      .query("follows")
      .withIndex("by_follower", (q) => q.eq("followerId", userId))
      .filter((q) => q.eq(q.field("status"), "accepted"))
      .collect();

    const followingIds = following.map(f => f.followingId);
    followingIds.push(userId); // Include user's own stories

    // Get active stories (not expired)
    const now = Date.now();
    const allPosts = await ctx.db.query("posts").collect();
    const stories = allPosts.filter(post => 
      post.isStory && 
      followingIds.includes(post.authorId) &&
      (!post.expiresAt || post.expiresAt > now) &&
      (post.privacy === "public" || 
       (post.privacy === "friends" && followingIds.includes(post.authorId)))
    );

    // Group stories by author
    const storiesByAuthor = new Map();
    for (const story of stories) {
      if (!storiesByAuthor.has(story.authorId)) {
        storiesByAuthor.set(story.authorId, []);
      }
      storiesByAuthor.get(story.authorId).push(story);
    }

    // Enrich with author info
    const enrichedStories = await Promise.all(
      Array.from(storiesByAuthor.entries()).map(async ([authorId, authorStories]) => {
        const author = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", authorId))
          .unique();

        const authorAvatarUrl = author?.avatar ? await ctx.storage.getUrl(author.avatar) : null;

        const storiesWithMedia = await Promise.all(
          (authorStories as any[]).map(async (story: any) => {
            const mediaUrl = story.mediaId ? await ctx.storage.getUrl(story.mediaId) : null;
            return { ...story, mediaUrl };
          })
        );

        return {
          authorId,
          author: author ? {
            ...author,
            avatarUrl: authorAvatarUrl,
          } : null,
          stories: storiesWithMedia.sort((a, b) => b._creationTime - a._creationTime),
        };
      })
    );

    return enrichedStories;
  },
});

export const getUserPosts = query({
  args: { userId: v.optional(v.id("users")) },
  handler: async (ctx, args) => {
    const currentUserId = await getAuthUserId(ctx);
    const targetUserId = args.userId || currentUserId;
    
    if (!targetUserId) return [];

    const posts = await ctx.db
      .query("posts")
      .withIndex("by_author", (q) => q.eq("authorId", targetUserId))
      .filter((q) => q.eq(q.field("isStory"), false))
      .order("desc")
      .collect();

    // Filter based on privacy and relationship
    let filteredPosts = posts;
    if (targetUserId !== currentUserId) {
      // Check if current user follows target user
      const followRelation = await ctx.db
        .query("follows")
        .withIndex("by_follower", (q) => q.eq("followerId", currentUserId!))
        .filter((q) => q.eq(q.field("followingId"), targetUserId))
        .filter((q) => q.eq(q.field("status"), "accepted"))
        .unique();

      const isFollowing = !!followRelation;
      
      filteredPosts = posts.filter(post => 
        post.privacy === "public" || 
        (post.privacy === "friends" && isFollowing)
      );
    }

    // Enrich posts with author info and media URLs
    const enrichedPosts = await Promise.all(
      filteredPosts.map(async (post) => {
        const author = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", post.authorId))
          .unique();

        const mediaUrl = post.mediaId ? await ctx.storage.getUrl(post.mediaId) : null;
        const authorAvatarUrl = author?.avatar ? await ctx.storage.getUrl(author.avatar) : null;

        return {
          ...post,
          author: author ? {
            ...author,
            avatarUrl: authorAvatarUrl,
          } : null,
          mediaUrl,
        };
      })
    );

    return enrichedPosts;
  },
});

export const generateUploadUrl = mutation({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    
    return await ctx.storage.generateUploadUrl();
  },
});

async function checkIsAdmin(ctx: any, userId: string) {
  const user = await ctx.db.get(userId);
  return user?.email === "mstrbystbyalrbyt@gmail.com";
}
