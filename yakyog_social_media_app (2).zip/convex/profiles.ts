import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createProfile = mutation({
  args: {
    firstName: v.string(),
    lastName: v.string(),
    birthDate: v.string(),
    bio: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const existingProfile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (existingProfile) {
      throw new Error("Profile already exists");
    }

    return await ctx.db.insert("profiles", {
      userId,
      firstName: args.firstName,
      lastName: args.lastName,
      birthDate: args.birthDate,
      bio: args.bio,
      isOnline: true,
      lastSeen: Date.now(),
    });
  },
});

export const getProfile = query({
  args: { userId: v.optional(v.id("users")) },
  handler: async (ctx, args) => {
    const currentUserId = await getAuthUserId(ctx);
    const targetUserId = args.userId || currentUserId;
    
    if (!targetUserId) return null;

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", targetUserId))
      .unique();

    if (!profile) return null;

    const user = await ctx.db.get(targetUserId);
    const avatarUrl = profile.avatar ? await ctx.storage.getUrl(profile.avatar) : null;

    return {
      ...profile,
      email: user?.email,
      avatarUrl,
    };
  },
});

export const updateProfile = mutation({
  args: {
    firstName: v.optional(v.string()),
    lastName: v.optional(v.string()),
    bio: v.optional(v.string()),
    avatar: v.optional(v.id("_storage")),
    isPrivate: v.optional(v.boolean()),
    showFollowers: v.optional(v.boolean()),
    language: v.optional(v.union(v.literal("ar"), v.literal("en"), v.literal("fr"))),
    theme: v.optional(v.union(v.literal("light"), v.literal("dark"))),
    gender: v.optional(v.union(v.literal("male"), v.literal("female"), v.literal("other"))),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!profile) throw new Error("Profile not found");

    const updates: any = {};
    if (args.firstName !== undefined) updates.firstName = args.firstName;
    if (args.lastName !== undefined) updates.lastName = args.lastName;
    if (args.bio !== undefined) updates.bio = args.bio;
    if (args.avatar !== undefined) updates.avatar = args.avatar;
    if (args.isPrivate !== undefined) updates.isPrivate = args.isPrivate;
    if (args.showFollowers !== undefined) updates.showFollowers = args.showFollowers;
    if (args.language !== undefined) updates.language = args.language;
    if (args.theme !== undefined) updates.theme = args.theme;
    if (args.gender !== undefined) updates.gender = args.gender;

    await ctx.db.patch(profile._id, updates);
  },
});

export const updateOnlineStatus = mutation({
  args: { isOnline: v.boolean() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (profile) {
      await ctx.db.patch(profile._id, {
        isOnline: args.isOnline,
        lastSeen: Date.now(),
      });
    }
  },
});

export const searchUsers = query({
  args: { searchTerm: v.string() },
  handler: async (ctx, args) => {
    const currentUserId = await getAuthUserId(ctx);
    if (!currentUserId) return [];

    const profiles = await ctx.db.query("profiles").collect();
    
    const filteredProfiles = profiles.filter(profile => {
      const fullName = `${profile.firstName} ${profile.lastName}`.toLowerCase();
      return fullName.includes(args.searchTerm.toLowerCase()) && profile.userId !== currentUserId;
    });

    const profilesWithAvatars = await Promise.all(
      filteredProfiles.map(async (profile) => {
        const avatarUrl = profile.avatar ? await ctx.storage.getUrl(profile.avatar) : null;
        return {
          ...profile,
          avatarUrl,
        };
      })
    );

    return profilesWithAvatars.slice(0, 10);
  },
});

export const generateUploadUrl = mutation({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    
    return await ctx.storage.generateUploadUrl();
  },
});
