import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getNotifications = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const notifications = await ctx.db
      .query("notifications")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(50);

    const enrichedNotifications = await Promise.all(
      notifications.map(async (notification) => {
        let fromUser = null;
        let post = null;
        let group = null;

        if (notification.fromUserId) {
          fromUser = await ctx.db
            .query("profiles")
            .withIndex("by_user", (q) => q.eq("userId", notification.fromUserId!))
            .unique();

          if (fromUser) {
            const avatarUrl = fromUser.avatar ? await ctx.storage.getUrl(fromUser.avatar) : null;
            fromUser = { ...fromUser, avatarUrl };
          }
        }

        if (notification.postId) {
          post = await ctx.db.get(notification.postId);
        }

        if (notification.groupId) {
          group = await ctx.db.get(notification.groupId);
        }

        return {
          ...notification,
          fromUser,
          post,
          group,
        };
      })
    );

    return enrichedNotifications;
  },
});

export const markNotificationAsRead = mutation({
  args: { notificationId: v.id("notifications") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const notification = await ctx.db.get(args.notificationId);
    if (!notification || notification.userId !== userId) {
      throw new Error("Notification not found");
    }

    await ctx.db.patch(args.notificationId, { isRead: true });
  },
});

export const getUnreadCount = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return 0;

    const unreadNotifications = await ctx.db
      .query("notifications")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => q.eq(q.field("isRead"), false))
      .collect();

    return unreadNotifications.length;
  },
});
