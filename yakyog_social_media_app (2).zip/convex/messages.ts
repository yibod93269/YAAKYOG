import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const sendDirectMessage = mutation({
  args: {
    receiverId: v.id("users"),
    content: v.string(),
    type: v.union(v.literal("text"), v.literal("image"), v.literal("video")),
    mediaId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.insert("directMessages", {
      senderId: userId,
      receiverId: args.receiverId,
      content: args.content,
      type: args.type,
      mediaId: args.mediaId,
      isRead: false,
    });
  },
});

export const getConversation = query({
  args: { otherUserId: v.id("users") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const messages = await ctx.db
      .query("directMessages")
      .filter((q) =>
        q.or(
          q.and(
            q.eq(q.field("senderId"), userId),
            q.eq(q.field("receiverId"), args.otherUserId)
          ),
          q.and(
            q.eq(q.field("senderId"), args.otherUserId),
            q.eq(q.field("receiverId"), userId)
          )
        )
      )
      .order("desc")
      .take(100);

    const enrichedMessages = await Promise.all(
      messages.map(async (message) => {
        const sender = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", message.senderId))
          .unique();

        const mediaUrl = message.mediaId ? await ctx.storage.getUrl(message.mediaId) : null;
        const senderAvatarUrl = sender?.avatar ? await ctx.storage.getUrl(sender.avatar) : null;

        return {
          ...message,
          sender: sender ? {
            ...sender,
            avatarUrl: senderAvatarUrl,
          } : null,
          mediaUrl,
        };
      })
    );

    return enrichedMessages.reverse();
  },
});

export const getConversations = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const messages = await ctx.db
      .query("directMessages")
      .filter((q) =>
        q.or(
          q.eq(q.field("senderId"), userId),
          q.eq(q.field("receiverId"), userId)
        )
      )
      .order("desc")
      .collect();

    // Group messages by conversation
    const conversationMap = new Map();
    
    for (const message of messages) {
      const otherUserId = message.senderId === userId ? message.receiverId : message.senderId;
      
      if (!conversationMap.has(otherUserId)) {
        conversationMap.set(otherUserId, {
          otherUserId,
          lastMessage: message,
          unreadCount: 0,
        });
      }
      
      // Count unread messages
      if (message.receiverId === userId && !message.isRead) {
        conversationMap.get(otherUserId).unreadCount++;
      }
    }

    const conversations = Array.from(conversationMap.values());

    // Enrich with user profiles
    const enrichedConversations = await Promise.all(
      conversations.map(async (conv) => {
        const otherUser = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", conv.otherUserId))
          .unique();

        const avatarUrl = otherUser?.avatar ? await ctx.storage.getUrl(otherUser.avatar) : null;

        return {
          ...conv,
          otherUser: otherUser ? {
            ...otherUser,
            avatarUrl,
          } : null,
        };
      })
    );

    return enrichedConversations.filter(conv => conv.otherUser);
  },
});

export const markMessagesAsRead = mutation({
  args: { otherUserId: v.id("users") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const unreadMessages = await ctx.db
      .query("directMessages")
      .filter((q) =>
        q.and(
          q.eq(q.field("senderId"), args.otherUserId),
          q.eq(q.field("receiverId"), userId),
          q.eq(q.field("isRead"), false)
        )
      )
      .collect();

    await Promise.all(
      unreadMessages.map(message => 
        ctx.db.patch(message._id, { isRead: true })
      )
    );
  },
});
