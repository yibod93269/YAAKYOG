import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

function generateInviteCode(): string {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

export const createGroup = mutation({
  args: {
    name: v.string(),
    description: v.optional(v.string()),
    avatar: v.optional(v.id("_storage")),
    isPrivate: v.boolean(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const inviteCode = generateInviteCode();

    return await ctx.db.insert("groups", {
      name: args.name,
      description: args.description,
      avatar: args.avatar,
      ownerId: userId,
      inviteCode,
      isPrivate: args.isPrivate,
      members: [userId],
    });
  },
});

export const joinGroupByCode = mutation({
  args: { inviteCode: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const group = await ctx.db
      .query("groups")
      .withIndex("by_invite_code", (q) => q.eq("inviteCode", args.inviteCode))
      .unique();

    if (!group) throw new Error("Invalid invite code");

    if (group.members.includes(userId)) {
      throw new Error("Already a member of this group");
    }

    await ctx.db.patch(group._id, {
      members: [...group.members, userId],
    });

    return group._id;
  },
});

export const leaveGroup = mutation({
  args: { groupId: v.id("groups") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const group = await ctx.db.get(args.groupId);
    if (!group) throw new Error("Group not found");

    if (!group.members.includes(userId)) {
      throw new Error("Not a member of this group");
    }

    if (group.ownerId === userId) {
      // If owner leaves, delete the group
      await ctx.db.delete(args.groupId);
    } else {
      // Remove user from members
      await ctx.db.patch(args.groupId, {
        members: group.members.filter(id => id !== userId),
      });
    }
  },
});

export const removeMember = mutation({
  args: {
    groupId: v.id("groups"),
    memberId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const group = await ctx.db.get(args.groupId);
    if (!group) throw new Error("Group not found");

    if (group.ownerId !== userId) {
      throw new Error("Only group owner can remove members");
    }

    if (args.memberId === userId) {
      throw new Error("Cannot remove yourself");
    }

    await ctx.db.patch(args.groupId, {
      members: group.members.filter(id => id !== args.memberId),
    });
  },
});

export const getUserGroups = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const allGroups = await ctx.db.query("groups").collect();
    const userGroups = allGroups.filter(group => group.members.includes(userId));

    const enrichedGroups = await Promise.all(
      userGroups.map(async (group) => {
        const avatarUrl = group.avatar ? await ctx.storage.getUrl(group.avatar) : null;
        const owner = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", group.ownerId))
          .unique();

        return {
          ...group,
          avatarUrl,
          owner,
          memberCount: group.members.length,
        };
      })
    );

    return enrichedGroups;
  },
});

export const getGroup = query({
  args: { groupId: v.id("groups") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const group = await ctx.db.get(args.groupId);
    if (!group || !group.members.includes(userId)) return null;

    const avatarUrl = group.avatar ? await ctx.storage.getUrl(group.avatar) : null;
    const owner = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", group.ownerId))
      .unique();

    const members = await Promise.all(
      group.members.map(async (memberId) => {
        const profile = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", memberId))
          .unique();
        
        const memberAvatarUrl = profile?.avatar ? await ctx.storage.getUrl(profile.avatar) : null;
        
        return profile ? {
          ...profile,
          avatarUrl: memberAvatarUrl,
        } : null;
      })
    );

    return {
      ...group,
      avatarUrl,
      owner,
      members: members.filter(Boolean),
    };
  },
});

export const sendGroupMessage = mutation({
  args: {
    groupId: v.id("groups"),
    content: v.string(),
    type: v.union(v.literal("text"), v.literal("image"), v.literal("video")),
    mediaId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const group = await ctx.db.get(args.groupId);
    if (!group || !group.members.includes(userId)) {
      throw new Error("Not a member of this group");
    }

    return await ctx.db.insert("groupMessages", {
      groupId: args.groupId,
      authorId: userId,
      content: args.content,
      type: args.type,
      mediaId: args.mediaId,
    });
  },
});

export const getGroupMessages = query({
  args: { groupId: v.id("groups") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const group = await ctx.db.get(args.groupId);
    if (!group || !group.members.includes(userId)) return [];

    const messages = await ctx.db
      .query("groupMessages")
      .withIndex("by_group", (q) => q.eq("groupId", args.groupId))
      .order("desc")
      .take(100);

    const enrichedMessages = await Promise.all(
      messages.map(async (message) => {
        const author = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", message.authorId))
          .unique();

        const mediaUrl = message.mediaId ? await ctx.storage.getUrl(message.mediaId) : null;
        const authorAvatarUrl = author?.avatar ? await ctx.storage.getUrl(author.avatar) : null;

        return {
          ...message,
          author: author ? {
            ...author,
            avatarUrl: authorAvatarUrl,
          } : null,
          mediaUrl,
        };
      })
    );

    return enrichedMessages.reverse();
  },
});
