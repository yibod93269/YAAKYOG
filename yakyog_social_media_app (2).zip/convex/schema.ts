import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // User profiles
  profiles: defineTable({
    userId: v.id("users"),
    firstName: v.string(),
    lastName: v.string(),
    birthDate: v.string(),
    bio: v.optional(v.string()),
    avatar: v.optional(v.id("_storage")),
    isOnline: v.boolean(),
    lastSeen: v.number(),
    isVerified: v.optional(v.boolean()),
    verifiedAt: v.optional(v.number()),
    verifiedBy: v.optional(v.id("users")),
    isPrivate: v.optional(v.boolean()),
    showFollowers: v.optional(v.boolean()),
    gender: v.optional(v.union(v.literal("male"), v.literal("female"), v.literal("other"))),
    language: v.optional(v.union(v.literal("ar"), v.literal("en"), v.literal("fr"))),
    theme: v.optional(v.union(v.literal("light"), v.literal("dark"))),
    role: v.optional(v.union(v.literal("user"), v.literal("admin"), v.literal("owner"))),
    isBanned: v.optional(v.boolean()),
    bannedAt: v.optional(v.number()),
    bannedBy: v.optional(v.id("users")),
    banReason: v.optional(v.string()),
    promotedAt: v.optional(v.number()),
    promotedBy: v.optional(v.id("users")),
  }).index("by_user", ["userId"])
    .index("by_role", ["role"])
    .index("by_verified", ["isVerified"]),

  // Posts with enhanced metadata
  posts: defineTable({
    authorId: v.id("users"),
    content: v.string(),
    type: v.union(v.literal("text"), v.literal("image"), v.literal("video"), v.literal("story"), v.literal("yogo")),
    mediaId: v.optional(v.id("_storage")),
    originalWidth: v.optional(v.number()),
    originalHeight: v.optional(v.number()),
    duration: v.optional(v.number()), // for videos
    fileSize: v.optional(v.number()),
    mimeType: v.optional(v.string()),
    likes: v.array(v.id("users")),
    isStory: v.boolean(),
    expiresAt: v.optional(v.number()),
    privacy: v.union(v.literal("public"), v.literal("friends")),
    isYogo: v.optional(v.boolean()),
    yogoType: v.optional(v.union(v.literal("public"), v.literal("friends"))),
    shares: v.optional(v.array(v.id("users"))),
    viewers: v.optional(v.array(v.id("users"))),
    isDeleted: v.optional(v.boolean()),
    deletedAt: v.optional(v.number()),
    deletedBy: v.optional(v.id("users")),
  }).index("by_author", ["authorId"])
    .index("by_type", ["type"])
    .index("by_privacy", ["privacy"])
    .index("by_deleted", ["isDeleted"]),

  // Comments
  comments: defineTable({
    postId: v.id("posts"),
    authorId: v.id("users"),
    content: v.string(),
    parentCommentId: v.optional(v.id("comments")),
    likes: v.optional(v.array(v.id("users"))),
    isDeleted: v.optional(v.boolean()),
    deletedAt: v.optional(v.number()),
    deletedBy: v.optional(v.id("users")),
  }).index("by_post", ["postId"])
    .index("by_parent", ["parentCommentId"]),

  // Follows
  follows: defineTable({
    followerId: v.id("users"),
    followingId: v.id("users"),
    status: v.union(v.literal("pending"), v.literal("accepted")),
  }).index("by_follower", ["followerId"])
    .index("by_following", ["followingId"]),

  // Groups
  groups: defineTable({
    name: v.string(),
    description: v.optional(v.string()),
    avatar: v.optional(v.id("_storage")),
    ownerId: v.id("users"),
    inviteCode: v.string(),
    isPrivate: v.boolean(),
    members: v.array(v.id("users")),
  }).index("by_owner", ["ownerId"])
    .index("by_invite_code", ["inviteCode"]),

  // Group messages
  groupMessages: defineTable({
    groupId: v.id("groups"),
    authorId: v.id("users"),
    content: v.string(),
    type: v.union(v.literal("text"), v.literal("image"), v.literal("video")),
    mediaId: v.optional(v.id("_storage")),
  }).index("by_group", ["groupId"]),

  // Direct messages
  directMessages: defineTable({
    senderId: v.id("users"),
    receiverId: v.id("users"),
    content: v.string(),
    type: v.union(v.literal("text"), v.literal("image"), v.literal("video"), v.literal("voice")),
    mediaId: v.optional(v.id("_storage")),
    isRead: v.boolean(),
  }).index("by_sender", ["senderId"])
    .index("by_receiver", ["receiverId"])
    .index("by_conversation", ["senderId", "receiverId"]),

  // Enhanced notifications
  notifications: defineTable({
    userId: v.id("users"),
    type: v.union(
      v.literal("follow_request"),
      v.literal("follow_accepted"),
      v.literal("like"),
      v.literal("comment"),
      v.literal("group_invite"),
      v.literal("story_like"),
      v.literal("post_share"),
      v.literal("yogo_like"),
      v.literal("verification_approved"),
      v.literal("verification_rejected"),
      v.literal("post_deleted"),
      v.literal("account_banned"),
      v.literal("account_unbanned")
    ),
    fromUserId: v.optional(v.id("users")),
    postId: v.optional(v.id("posts")),
    groupId: v.optional(v.id("groups")),
    message: v.optional(v.string()),
    isRead: v.boolean(),
  }).index("by_user", ["userId"])
    .index("by_type", ["type"]),

  // Enhanced verification requests
  verificationRequests: defineTable({
    userId: v.id("users"),
    status: v.union(v.literal("pending"), v.literal("approved"), v.literal("rejected")),
    reason: v.optional(v.string()),
    documents: v.optional(v.array(v.id("_storage"))),
    socialLinks: v.optional(v.array(v.string())),
    reviewedBy: v.optional(v.id("users")),
    reviewedAt: v.optional(v.number()),
    adminNote: v.optional(v.string()),
    rejectionReason: v.optional(v.string()),
  }).index("by_user", ["userId"])
    .index("by_status", ["status"]),

  // Site settings
  siteSettings: defineTable({
    siteName: v.string(),
    primaryColor: v.string(),
    accentColor: v.string(),
    maxUploadSize: v.number(),
    allowedFileTypes: v.array(v.string()),
    enableStories: v.boolean(),
    enableLiveStreaming: v.boolean(),
    maintenanceMode: v.boolean(),
    updatedBy: v.id("users"),
    updatedAt: v.optional(v.number()),
  }),

  // Audit logs for admin actions
  auditLogs: defineTable({
    action: v.string(),
    actorId: v.id("users"),
    targetId: v.optional(v.string()),
    details: v.optional(v.string()),
  }).index("by_actor", ["actorId"])
    .index("by_action", ["action"]),

  // Media metadata
  mediaFiles: defineTable({
    postId: v.optional(v.id("posts")),
    userId: v.id("users"),
    storageId: v.id("_storage"),
    originalName: v.string(),
    mimeType: v.string(),
    fileSize: v.number(),
    originalWidth: v.optional(v.number()),
    originalHeight: v.optional(v.number()),
    duration: v.optional(v.number()),
    thumbnailId: v.optional(v.id("_storage")),
    isProcessed: v.boolean(),
    processingError: v.optional(v.string()),
  }).index("by_user", ["userId"])
    .index("by_post", ["postId"])
    .index("by_storage", ["storageId"]),

  // YAKCOINS system
  yakcoins: defineTable({
    userId: v.id("users"),
    balance: v.number(),
    totalEarned: v.number(),
    totalSpent: v.number(),
  }).index("by_user", ["userId"]),

  // YAKCOINS transactions
  yakcoinTransactions: defineTable({
    userId: v.id("users"),
    type: v.union(v.literal("earn"), v.literal("spend"), v.literal("transfer")),
    amount: v.number(),
    reason: v.string(),
    fromUserId: v.optional(v.id("users")),
    toUserId: v.optional(v.id("users")),
    postId: v.optional(v.id("posts")),
  }).index("by_user", ["userId"])
    .index("by_type", ["type"]),

  // Password reset tokens
  passwordResetTokens: defineTable({
    email: v.string(),
    token: v.string(),
    expiresAt: v.number(),
  }).index("by_email", ["email"])
    .index("by_token", ["token"]),

  // Email verification tokens
  emailVerificationTokens: defineTable({
    email: v.string(),
    token: v.string(),
    expiresAt: v.number(),
  }).index("by_email", ["email"])
    .index("by_token", ["token"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
