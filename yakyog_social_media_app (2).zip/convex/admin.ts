import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

// Check if user is the owner (super admin)
async function checkIsOwner(ctx: any, userId: string) {
  const user = await ctx.db.get(userId);
  return user?.email === "mstrbystbyalrbyt@gmail.com";
}

// Check if user is admin or owner
async function checkIsAdminOrOwner(ctx: any, userId: string) {
  const user = await ctx.db.get(userId);
  const profile = await ctx.db
    .query("profiles")
    .withIndex("by_user", (q: any) => q.eq("userId", userId))
    .unique();
  
  return user?.email === "mstrbystbyalrbyt@gmail.com" || profile?.role === "admin";
}

export const isAdmin = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return false;
    
    return await checkIsAdminOrOwner(ctx, userId);
  },
});

export const getDashboardStats = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId || !(await checkIsAdminOrOwner(ctx, userId))) {
      throw new Error("Unauthorized");
    }

    const users = await ctx.db.query("profiles").collect();
    const posts = await ctx.db.query("posts").collect();
    const comments = await ctx.db.query("comments").collect();
    const verificationRequests = await ctx.db
      .query("verificationRequests")
      .withIndex("by_status", (q) => q.eq("status", "pending"))
      .collect();

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayPosts = posts.filter(p => p._creationTime >= today.getTime());
    const onlineUsers = users.filter(u => u.isOnline);

    return {
      totalUsers: users.length,
      totalPosts: posts.length,
      totalComments: comments.length,
      todayPosts: todayPosts.length,
      onlineUsers: onlineUsers.length,
      pendingVerifications: verificationRequests.length,
      verifiedUsers: users.filter(u => u.isVerified).length,
    };
  },
});

export const getAllUsers = query({
  args: {
    filter: v.optional(v.union(v.literal("all"), v.literal("verified"), v.literal("banned"))),
    search: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId || !(await checkIsAdminOrOwner(ctx, userId))) {
      throw new Error("Unauthorized");
    }

    let profiles = await ctx.db.query("profiles").collect();

    // Apply filters
    if (args.filter === "verified") {
      profiles = profiles.filter(p => p.isVerified);
    } else if (args.filter === "banned") {
      profiles = profiles.filter(p => p.isBanned);
    }

    // Apply search
    if (args.search) {
      const searchTerm = args.search.toLowerCase();
      profiles = profiles.filter(p => 
        `${p.firstName} ${p.lastName}`.toLowerCase().includes(searchTerm)
      );
    }

    // Enrich with user data and avatar URLs
    const enrichedProfiles = await Promise.all(
      profiles.map(async (profile) => {
        const user = await ctx.db.get(profile.userId);
        const avatarUrl = profile.avatar ? await ctx.storage.getUrl(profile.avatar) : null;
        
        return {
          ...profile,
          email: user?.email,
          avatarUrl,
        };
      })
    );

    return enrichedProfiles;
  },
});

export const getAllPosts = query({
  args: {
    filter: v.optional(v.union(v.literal("all"), v.literal("reported"), v.literal("deleted"))),
    search: v.optional(v.string()),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId || !(await checkIsAdminOrOwner(ctx, userId))) {
      throw new Error("Unauthorized");
    }

    let posts = await ctx.db.query("posts").order("desc").take(args.limit || 50);

    // Apply filters
    if (args.filter === "deleted") {
      posts = posts.filter(p => p.isDeleted);
    }

    // Apply search
    if (args.search) {
      const searchTerm = args.search.toLowerCase();
      posts = posts.filter(p => 
        p.content.toLowerCase().includes(searchTerm)
      );
    }

    // Enrich with author data and media URLs
    const enrichedPosts = await Promise.all(
      posts.map(async (post) => {
        const profile = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", post.authorId))
          .unique();

        const mediaUrl = post.mediaId ? await ctx.storage.getUrl(post.mediaId) : null;
        
        // Get comments count
        const commentsCount = await ctx.db
          .query("comments")
          .withIndex("by_post", (q) => q.eq("postId", post._id))
          .collect()
          .then(comments => comments.length);

        return {
          ...post,
          author: profile ? {
            firstName: profile.firstName,
            lastName: profile.lastName,
            avatarUrl: profile.avatar ? await ctx.storage.getUrl(profile.avatar) : null,
          } : null,
          mediaUrl,
          commentsCount,
          likesCount: post.likes.length,
        };
      })
    );

    return enrichedPosts;
  },
});

export const getAllComments = query({
  args: {
    postId: v.optional(v.id("posts")),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId || !(await checkIsAdminOrOwner(ctx, userId))) {
      throw new Error("Unauthorized");
    }

    let comments;
    
    if (args.postId) {
      comments = await ctx.db
        .query("comments")
        .withIndex("by_post", (q: any) => q.eq("postId", args.postId))
        .order("desc")
        .take(args.limit || 100);
    } else {
      comments = await ctx.db
        .query("comments")
        .order("desc")
        .take(args.limit || 100);
    }

    // Enrich with author data
    const enrichedComments = await Promise.all(
      comments.map(async (comment) => {
        const profile = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q: any) => q.eq("userId", comment.authorId))
          .unique();

        const post = await ctx.db.get(comment.postId);

        return {
          ...comment,
          author: profile ? {
            firstName: profile.firstName,
            lastName: profile.lastName,
            avatarUrl: profile.avatar ? await ctx.storage.getUrl(profile.avatar) : null,
          } : null,
          post: post ? {
            content: post.content.substring(0, 100) + (post.content.length > 100 ? "..." : ""),
          } : null,
          likesCount: comment.likes?.length || 0,
        };
      })
    );

    return enrichedComments;
  },
});

export const banUser = mutation({
  args: { 
    userId: v.id("users"),
    reason: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const adminId = await getAuthUserId(ctx);
    if (!adminId || !(await checkIsAdminOrOwner(ctx, adminId))) {
      throw new Error("Unauthorized");
    }

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .unique();

    if (!profile) throw new Error("User not found");

    await ctx.db.patch(profile._id, {
      isBanned: true,
      bannedAt: Date.now(),
      bannedBy: adminId,
      banReason: args.reason,
    });

    // Log the action
    await ctx.db.insert("auditLogs", {
      action: "ban_user",
      actorId: adminId,
      targetId: args.userId,
      details: args.reason || "No reason provided",
    });
  },
});

export const unbanUser = mutation({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const adminId = await getAuthUserId(ctx);
    if (!adminId || !(await checkIsAdminOrOwner(ctx, adminId))) {
      throw new Error("Unauthorized");
    }

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .unique();

    if (!profile) throw new Error("User not found");

    await ctx.db.patch(profile._id, {
      isBanned: false,
      bannedAt: undefined,
      bannedBy: undefined,
      banReason: undefined,
    });

    await ctx.db.insert("auditLogs", {
      action: "unban_user",
      actorId: adminId,
      targetId: args.userId,
      details: "User unbanned",
    });
  },
});

export const promoteToAdmin = mutation({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const ownerId = await getAuthUserId(ctx);
    if (!ownerId || !(await checkIsOwner(ctx, ownerId))) {
      throw new Error("Only owner can promote users to admin");
    }

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .unique();

    if (!profile) throw new Error("User not found");

    await ctx.db.patch(profile._id, {
      role: "admin",
      promotedAt: Date.now(),
      promotedBy: ownerId,
    });

    await ctx.db.insert("auditLogs", {
      action: "promote_to_admin",
      actorId: ownerId,
      targetId: args.userId,
      details: "User promoted to admin",
    });
  },
});

export const demoteFromAdmin = mutation({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const ownerId = await getAuthUserId(ctx);
    if (!ownerId || !(await checkIsOwner(ctx, ownerId))) {
      throw new Error("Only owner can demote admins");
    }

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .unique();

    if (!profile) throw new Error("User not found");

    await ctx.db.patch(profile._id, {
      role: "user",
      promotedAt: undefined,
      promotedBy: undefined,
    });

    await ctx.db.insert("auditLogs", {
      action: "demote_from_admin",
      actorId: ownerId,
      targetId: args.userId,
      details: "Admin demoted to user",
    });
  },
});

export const deleteAnyPost = mutation({
  args: { 
    postId: v.id("posts"),
    reason: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const adminId = await getAuthUserId(ctx);
    if (!adminId || !(await checkIsAdminOrOwner(ctx, adminId))) {
      throw new Error("Unauthorized");
    }

    const post = await ctx.db.get(args.postId);
    if (!post) throw new Error("Post not found");

    // Delete associated comments
    const comments = await ctx.db
      .query("comments")
      .withIndex("by_post", (q) => q.eq("postId", args.postId))
      .collect();

    for (const comment of comments) {
      await ctx.db.delete(comment._id);
    }

    // Delete the post
    await ctx.db.delete(args.postId);

    // Log the action
    await ctx.db.insert("auditLogs", {
      action: "delete_post",
      actorId: adminId,
      targetId: args.postId,
      details: args.reason || "Post deleted by admin",
    });

    // Notify post author
    if (post.authorId !== adminId) {
      await ctx.db.insert("notifications", {
        userId: post.authorId,
        type: "post_deleted",
        fromUserId: adminId,
        postId: args.postId,
        isRead: false,
        message: args.reason || "Your post was deleted by an administrator",
      });
    }
  },
});

export const deleteAnyComment = mutation({
  args: { 
    commentId: v.id("comments"),
    reason: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const adminId = await getAuthUserId(ctx);
    if (!adminId || !(await checkIsAdminOrOwner(ctx, adminId))) {
      throw new Error("Unauthorized");
    }

    const comment = await ctx.db.get(args.commentId);
    if (!comment) throw new Error("Comment not found");

    // Delete the comment
    await ctx.db.delete(args.commentId);

    // Log the action
    await ctx.db.insert("auditLogs", {
      action: "delete_comment",
      actorId: adminId,
      targetId: args.commentId,
      details: args.reason || "Comment deleted by admin",
    });

    // Notify comment author
    if (comment.authorId !== adminId) {
      await ctx.db.insert("notifications", {
        userId: comment.authorId,
        type: "post_deleted", // Reusing this type for comments
        fromUserId: adminId,
        isRead: false,
        message: args.reason || "Your comment was deleted by an administrator",
      });
    }
  },
});

export const getAuditLogs = query({
  args: {
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId || !(await checkIsAdminOrOwner(ctx, userId))) {
      throw new Error("Unauthorized");
    }

    const logs = await ctx.db
      .query("auditLogs")
      .order("desc")
      .take(args.limit || 50);

    // Enrich with actor names
    const enrichedLogs = await Promise.all(
      logs.map(async (log) => {
        const actor = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", log.actorId))
          .unique();

        return {
          ...log,
          actorName: actor ? `${actor.firstName} ${actor.lastName}` : "Unknown",
        };
      })
    );

    return enrichedLogs;
  },
});

export const updateSiteSettings = mutation({
  args: {
    siteName: v.optional(v.string()),
    primaryColor: v.optional(v.string()),
    accentColor: v.optional(v.string()),
    maxUploadSize: v.optional(v.number()),
    allowedFileTypes: v.optional(v.array(v.string())),
    enableStories: v.optional(v.boolean()),
    enableLiveStreaming: v.optional(v.boolean()),
    maintenanceMode: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const ownerId = await getAuthUserId(ctx);
    if (!ownerId || !(await checkIsOwner(ctx, ownerId))) {
      throw new Error("Only owner can update site settings");
    }

    // Get or create site settings
    let settings = await ctx.db.query("siteSettings").unique();
    
    if (!settings) {
      const settingsId = await ctx.db.insert("siteSettings", {
        siteName: "YAK Social",
        primaryColor: "#3b82f6",
        accentColor: "#10b981",
        maxUploadSize: 100 * 1024 * 1024, // 100MB
        allowedFileTypes: ["image/jpeg", "image/png", "image/gif", "video/mp4", "video/webm"],
        enableStories: true,
        enableLiveStreaming: false,
        maintenanceMode: false,
        updatedBy: ownerId,
      });
      
      await ctx.db.insert("auditLogs", {
        action: "update_site_settings",
        actorId: ownerId,
        targetId: settingsId,
        details: "Site settings updated",
      });
    } else {
      const updates: any = { updatedBy: ownerId, updatedAt: Date.now() };
      
      if (args.siteName !== undefined) updates.siteName = args.siteName;
      if (args.primaryColor !== undefined) updates.primaryColor = args.primaryColor;
      if (args.accentColor !== undefined) updates.accentColor = args.accentColor;
      if (args.maxUploadSize !== undefined) updates.maxUploadSize = args.maxUploadSize;
      if (args.allowedFileTypes !== undefined) updates.allowedFileTypes = args.allowedFileTypes;
      if (args.enableStories !== undefined) updates.enableStories = args.enableStories;
      if (args.enableLiveStreaming !== undefined) updates.enableLiveStreaming = args.enableLiveStreaming;
      if (args.maintenanceMode !== undefined) updates.maintenanceMode = args.maintenanceMode;

      await ctx.db.patch(settings._id, updates);
      
      await ctx.db.insert("auditLogs", {
        action: "update_site_settings",
        actorId: ownerId,
        targetId: settings._id,
        details: "Site settings updated",
      });
    }
  },
});

export const getSiteSettings = query({
  args: {},
  handler: async (ctx) => {
    const settings = await ctx.db.query("siteSettings").unique();
    
    if (!settings) {
      return {
        siteName: "YAK Social",
        primaryColor: "#3b82f6",
        accentColor: "#10b981",
        maxUploadSize: 100 * 1024 * 1024,
        allowedFileTypes: ["image/jpeg", "image/png", "image/gif", "video/mp4", "video/webm"],
        enableStories: true,
        enableLiveStreaming: false,
        maintenanceMode: false,
      };
    }

    return settings;
  },
});
