import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

export function StoriesBar() {
  const [selectedStory, setSelectedStory] = useState<any>(null);
  const [currentStoryIndex, setCurrentStoryIndex] = useState(0);

  const stories = useQuery(api.posts.getStories) || [];
  const viewStory = useMutation(api.posts.viewStory);
  const likePost = useMutation(api.posts.likePost);

  const handleStoryClick = async (storyGroup: any) => {
    setSelectedStory(storyGroup);
    setCurrentStoryIndex(0);
    
    // Mark first story as viewed
    if (storyGroup.stories[0]) {
      await viewStory({ postId: storyGroup.stories[0]._id });
    }
  };

  const handleNextStory = async () => {
    if (!selectedStory) return;
    
    const nextIndex = currentStoryIndex + 1;
    if (nextIndex < selectedStory.stories.length) {
      setCurrentStoryIndex(nextIndex);
      await viewStory({ postId: selectedStory.stories[nextIndex]._id });
    } else {
      // Move to next user's stories or close
      const currentUserIndex = stories.findIndex(s => s.authorId === selectedStory.authorId);
      if (currentUserIndex < stories.length - 1) {
        const nextUserStories = stories[currentUserIndex + 1];
        setSelectedStory(nextUserStories);
        setCurrentStoryIndex(0);
        await viewStory({ postId: nextUserStories.stories[0]._id });
      } else {
        setSelectedStory(null);
      }
    }
  };

  const handlePrevStory = async () => {
    if (!selectedStory) return;
    
    const prevIndex = currentStoryIndex - 1;
    if (prevIndex >= 0) {
      setCurrentStoryIndex(prevIndex);
      await viewStory({ postId: selectedStory.stories[prevIndex]._id });
    } else {
      // Move to previous user's stories
      const currentUserIndex = stories.findIndex(s => s.authorId === selectedStory.authorId);
      if (currentUserIndex > 0) {
        const prevUserStories = stories[currentUserIndex - 1];
        setSelectedStory(prevUserStories);
        setCurrentStoryIndex(prevUserStories.stories.length - 1);
        await viewStory({ postId: prevUserStories.stories[prevUserStories.stories.length - 1]._id });
      }
    }
  };

  const handleLikeStory = async () => {
    if (!selectedStory || !selectedStory.stories[currentStoryIndex]) return;
    
    try {
      await likePost({ postId: selectedStory.stories[currentStoryIndex]._id });
    } catch (error) {
      console.error("Error liking story:", error);
    }
  };

  if (stories.length === 0) {
    return null;
  }

  const currentStory = selectedStory?.stories[currentStoryIndex];

  return (
    <>
      {/* Stories Bar */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 mb-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">القصص</h3>
        <div className="flex space-x-4 space-x-reverse overflow-x-auto pb-2">
          {stories.map((storyGroup) => (
            <button
              key={storyGroup.authorId}
              onClick={() => handleStoryClick(storyGroup)}
              className="flex-shrink-0 text-center"
            >
              <div className="relative mb-2">
                <div className="w-16 h-16 rounded-full p-1 bg-gradient-to-r from-pink-500 to-purple-500">
                  {storyGroup.author?.avatarUrl ? (
                    <img
                      src={storyGroup.author.avatarUrl}
                      alt={`${storyGroup.author.firstName} ${storyGroup.author.lastName}`}
                      className="w-full h-full rounded-full object-cover border-2 border-white"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center border-2 border-white">
                      <span className="text-white font-semibold text-sm">
                        {storyGroup.author?.firstName[0]}
                      </span>
                    </div>
                  )}
                </div>
                <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 rounded-full border-2 border-white flex items-center justify-center">
                  <span className="text-white text-xs">{storyGroup.stories.length}</span>
                </div>
              </div>
              <p className="text-xs text-gray-600 max-w-16 truncate">
                {storyGroup.author?.firstName}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Story Viewer Modal */}
      {selectedStory && currentStory && (
        <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
          {/* Story Progress Bar */}
          <div className="absolute top-4 left-4 right-4 flex space-x-1 space-x-reverse z-10">
            {selectedStory.stories.map((_: any, index: number) => (
              <div
                key={index}
                className={`flex-1 h-1 rounded-full ${
                  index < currentStoryIndex ? "bg-white" :
                  index === currentStoryIndex ? "bg-white bg-opacity-70" :
                  "bg-white bg-opacity-30"
                }`}
              />
            ))}
          </div>

          {/* Story Header */}
          <div className="absolute top-8 left-4 right-4 flex items-center justify-between z-10">
            <div className="flex items-center space-x-3 space-x-reverse">
              {selectedStory.author?.avatarUrl ? (
                <img
                  src={selectedStory.author.avatarUrl}
                  alt={`${selectedStory.author.firstName} ${selectedStory.author.lastName}`}
                  className="w-10 h-10 rounded-full object-cover border-2 border-white"
                />
              ) : (
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center border-2 border-white">
                  <span className="text-white font-semibold">
                    {selectedStory.author?.firstName[0]}
                  </span>
                </div>
              )}
              <div>
                <p className="text-white font-semibold">
                  {selectedStory.author?.firstName} {selectedStory.author?.lastName}
                </p>
                <p className="text-white text-sm opacity-70">
                  {formatDistanceToNow(new Date(currentStory._creationTime), {
                    addSuffix: true,
                    locale: ar,
                  })}
                </p>
              </div>
            </div>
            
            <button
              onClick={() => setSelectedStory(null)}
              className="text-white text-2xl hover:text-gray-300"
            >
              ✕
            </button>
          </div>

          {/* Story Content */}
          <div className="relative w-full h-full flex items-center justify-center">
            {currentStory.mediaUrl ? (
              currentStory.type === "image" ? (
                <img
                  src={currentStory.mediaUrl}
                  alt="Story content"
                  className="max-w-full max-h-full object-contain"
                />
              ) : (
                <video
                  src={currentStory.mediaUrl}
                  className="max-w-full max-h-full object-contain"
                  autoPlay
                  muted
                  onEnded={handleNextStory}
                />
              )
            ) : (
              <div className="bg-gradient-to-br from-blue-500 to-purple-600 w-full h-full flex items-center justify-center p-8">
                <p className="text-white text-2xl text-center font-medium">
                  {currentStory.content}
                </p>
              </div>
            )}

            {/* Navigation Areas */}
            <button
              onClick={handlePrevStory}
              className="absolute left-0 top-0 w-1/3 h-full z-10"
            />
            <button
              onClick={handleNextStory}
              className="absolute right-0 top-0 w-1/3 h-full z-10"
            />
          </div>

          {/* Story Actions */}
          <div className="absolute bottom-8 left-4 right-4 flex items-center justify-between z-10">
            <div className="flex items-center space-x-4 space-x-reverse">
              <button
                onClick={handleLikeStory}
                className={`text-2xl ${
                  currentStory.likes?.includes(selectedStory.author?.userId) ? "text-red-500" : "text-white"
                }`}
              >
                {currentStory.likes?.includes(selectedStory.author?.userId) ? "❤️" : "🤍"}
              </button>
              <span className="text-white text-sm">
                {currentStory.likes?.length || 0} إعجاب
              </span>
            </div>

            <div className="flex items-center space-x-2 space-x-reverse text-white text-sm">
              <span>👁️</span>
              <span>{currentStory.viewers?.length || 0}</span>
            </div>
          </div>

          {/* Story Content Text */}
          {currentStory.content && currentStory.mediaUrl && (
            <div className="absolute bottom-20 left-4 right-4 z-10">
              <p className="text-white text-center bg-black bg-opacity-50 rounded-xl p-3">
                {currentStory.content}
              </p>
            </div>
          )}
        </div>
      )}
    </>
  );
}
