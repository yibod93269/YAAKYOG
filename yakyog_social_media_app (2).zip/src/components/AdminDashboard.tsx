import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../../convex/_generated/dataModel";

export function AdminDashboard({ onClose }: { onClose: () => void }) {
  const [activeTab, setActiveTab] = useState("overview");
  
  const stats = useQuery(api.admin.getDashboardStats);
  const users = useQuery(api.admin.getAllUsers, {});
  const posts = useQuery(api.admin.getAllPosts, {});
  const comments = useQuery(api.admin.getAllComments, {});
  const pendingVerifications = useQuery(api.verification.getPendingVerifications);
  const auditLogs = useQuery(api.admin.getAuditLogs, { limit: 20 });
  const siteSettings = useQuery(api.admin.getSiteSettings);

  const banUser = useMutation(api.admin.banUser);
  const unbanUser = useMutation(api.admin.unbanUser);
  const promoteToAdmin = useMutation(api.admin.promoteToAdmin);
  const demoteFromAdmin = useMutation(api.admin.demoteFromAdmin);
  const deletePost = useMutation(api.admin.deleteAnyPost);
  const deleteComment = useMutation(api.admin.deleteAnyComment);
  const approveVerification = useMutation(api.verification.approveVerification);
  const rejectVerification = useMutation(api.verification.rejectVerification);
  const updateSiteSettings = useMutation(api.admin.updateSiteSettings);

  const handleBanUser = async (userId: Id<"users">, reason?: string) => {
    try {
      await banUser({ userId, reason });
      toast.success("تم حظر المستخدم بنجاح");
    } catch (error) {
      toast.error("حدث خطأ أثناء حظر المستخدم");
    }
  };

  const handleUnbanUser = async (userId: Id<"users">) => {
    try {
      await unbanUser({ userId });
      toast.success("تم إلغاء حظر المستخدم بنجاح");
    } catch (error) {
      toast.error("حدث خطأ أثناء إلغاء الحظر");
    }
  };

  const handlePromoteToAdmin = async (userId: Id<"users">) => {
    try {
      await promoteToAdmin({ userId });
      toast.success("تم ترقية المستخدم إلى مدير بنجاح");
    } catch (error) {
      toast.error("حدث خطأ أثناء الترقية");
    }
  };

  const handleDeletePost = async (postId: Id<"posts">, reason?: string) => {
    try {
      await deletePost({ postId, reason });
      toast.success("تم حذف المنشور بنجاح");
    } catch (error) {
      toast.error("حدث خطأ أثناء حذف المنشور");
    }
  };

  const handleDeleteComment = async (commentId: Id<"comments">, reason?: string) => {
    try {
      await deleteComment({ commentId, reason });
      toast.success("تم حذف التعليق بنجاح");
    } catch (error) {
      toast.error("حدث خطأ أثناء حذف التعليق");
    }
  };

  const handleApproveVerification = async (requestId: Id<"verificationRequests">, note?: string) => {
    try {
      await approveVerification({ requestId, adminNote: note });
      toast.success("تم قبول طلب التوثيق بنجاح");
    } catch (error) {
      toast.error("حدث خطأ أثناء قبول الطلب");
    }
  };

  const handleRejectVerification = async (requestId: Id<"verificationRequests">, reason: string) => {
    try {
      await rejectVerification({ requestId, reason });
      toast.success("تم رفض طلب التوثيق");
    } catch (error) {
      toast.error("حدث خطأ أثناء رفض الطلب");
    }
  };

  const tabs = [
    { id: "overview", label: "نظرة عامة", icon: "📊" },
    { id: "users", label: "إدارة المستخدمين", icon: "👥" },
    { id: "content", label: "إدارة المحتوى", icon: "📝" },
    { id: "verifications", label: "طلبات التوثيق", icon: "✓" },
    { id: "settings", label: "إعدادات الموقع", icon: "⚙️" },
    { id: "logs", label: "سجل العمليات", icon: "📋" },
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-7xl w-full max-h-[95vh] overflow-hidden flex">
        {/* Sidebar */}
        <div className="w-1/4 bg-gradient-to-b from-blue-600 to-purple-700 p-6">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-white">لوحة الإدارة</h2>
            <button
              onClick={onClose}
              className="text-white hover:text-gray-200 text-2xl"
            >
              ✕
            </button>
          </div>

          <nav className="space-y-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center space-x-3 space-x-reverse p-4 rounded-xl transition-all ${
                  activeTab === tab.id
                    ? "bg-white text-blue-600 shadow-lg"
                    : "text-white hover:bg-white hover:bg-opacity-20"
                }`}
              >
                <span className="text-xl">{tab.icon}</span>
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="flex-1 p-8 overflow-y-auto">
          {activeTab === "overview" && (
            <OverviewTab stats={stats} />
          )}

          {activeTab === "users" && (
            <UsersTab 
              users={users || []}
              onBanUser={handleBanUser}
              onUnbanUser={handleUnbanUser}
              onPromoteToAdmin={handlePromoteToAdmin}
            />
          )}

          {activeTab === "content" && (
            <ContentTab
              posts={posts || []}
              comments={comments || []}
              onDeletePost={handleDeletePost}
              onDeleteComment={handleDeleteComment}
            />
          )}

          {activeTab === "verifications" && (
            <VerificationsTab
              verifications={pendingVerifications || []}
              onApprove={handleApproveVerification}
              onReject={handleRejectVerification}
            />
          )}

          {activeTab === "settings" && (
            <SiteSettingsTab
              settings={siteSettings}
              onUpdate={updateSiteSettings}
            />
          )}

          {activeTab === "logs" && (
            <AuditLogsTab logs={auditLogs || []} />
          )}
        </div>
      </div>
    </div>
  );
}

function OverviewTab({ stats }: { stats: any }) {
  if (!stats) return <div>جاري التحميل...</div>;

  const statCards = [
    { label: "إجمالي المستخدمين", value: stats.totalUsers, icon: "👥", color: "blue" },
    { label: "إجمالي المنشورات", value: stats.totalPosts, icon: "📝", color: "green" },
    { label: "إجمالي التعليقات", value: stats.totalComments, icon: "💬", color: "yellow" },
    { label: "منشورات اليوم", value: stats.todayPosts, icon: "📅", color: "purple" },
    { label: "المستخدمون المتصلون", value: stats.onlineUsers, icon: "🟢", color: "emerald" },
    { label: "طلبات التوثيق المعلقة", value: stats.pendingVerifications, icon: "⏳", color: "orange" },
    { label: "المستخدمون الموثقون", value: stats.verifiedUsers, icon: "✓", color: "indigo" },
  ];

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold text-gray-800">نظرة عامة</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {statCards.map((stat, index) => (
          <div key={index} className={`bg-gradient-to-r from-${stat.color}-500 to-${stat.color}-600 rounded-2xl p-6 text-white shadow-lg`}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">{stat.label}</p>
                <p className="text-3xl font-bold">{stat.value}</p>
              </div>
              <div className="text-4xl opacity-80">{stat.icon}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h2 className="text-xl font-bold text-gray-800 mb-4">إحصائيات سريعة</h2>
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-gray-600">معدل النمو اليومي</span>
            <span className="text-green-600 font-semibold">+{Math.round((stats.todayPosts / stats.totalPosts) * 100)}%</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-600">نسبة المستخدمين المتصلين</span>
            <span className="text-blue-600 font-semibold">{Math.round((stats.onlineUsers / stats.totalUsers) * 100)}%</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-600">نسبة المستخدمين الموثقين</span>
            <span className="text-purple-600 font-semibold">{Math.round((stats.verifiedUsers / stats.totalUsers) * 100)}%</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-600">متوسط التعليقات لكل منشور</span>
            <span className="text-orange-600 font-semibold">{(stats.totalComments / stats.totalPosts).toFixed(1)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function UsersTab({ users, onBanUser, onUnbanUser, onPromoteToAdmin }: any) {
  const [searchTerm, setSearchTerm] = useState("");
  const [filter, setFilter] = useState("all");

  const filteredUsers = users.filter((user: any) => {
    const matchesSearch = `${user.firstName} ${user.lastName}`.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filter === "all" || 
      (filter === "verified" && user.isVerified) ||
      (filter === "banned" && user.isBanned) ||
      (filter === "admin" && user.role === "admin");
    
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">إدارة المستخدمين</h1>
      
      {/* Filters */}
      <div className="flex space-x-4 space-x-reverse">
        <input
          type="text"
          placeholder="البحث عن المستخدمين..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none"
        />
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none"
        >
          <option value="all">جميع المستخدمين</option>
          <option value="verified">الموثقون</option>
          <option value="banned">المحظورون</option>
          <option value="admin">المدراء</option>
        </select>
      </div>

      {/* Users List */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-4 text-right text-sm font-semibold text-gray-600">المستخدم</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-gray-600">البريد الإلكتروني</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-gray-600">الحالة</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-gray-600">الدور</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-gray-600">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredUsers.map((user: any) => (
                <tr key={user.userId} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-3 space-x-reverse">
                      {user.avatarUrl ? (
                        <img src={user.avatarUrl} alt="" className="w-10 h-10 rounded-full object-cover" />
                      ) : (
                        <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                          <span className="text-white font-semibold text-sm">
                            {user.firstName[0]}{user.lastName[0]}
                          </span>
                        </div>
                      )}
                      <div>
                        <div className="flex items-center space-x-2 space-x-reverse">
                          <p className="font-semibold text-gray-800">{user.firstName} {user.lastName}</p>
                          {user.isVerified && <span className="text-blue-500">✓</span>}
                        </div>
                        <p className="text-sm text-gray-500">انضم في {new Date(user._creationTime).toLocaleDateString('ar')}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-gray-600">{user.email}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <div className={`w-3 h-3 rounded-full ${user.isOnline ? 'bg-green-500' : 'bg-red-500'}`}></div>
                      <span className="text-sm">{user.isOnline ? 'متصل' : 'غير متصل'}</span>
                      {user.isBanned && <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">محظور</span>}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      user.role === 'admin' ? 'bg-purple-100 text-purple-800' :
                      user.role === 'owner' ? 'bg-red-100 text-red-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {user.role === 'admin' ? 'مدير' : user.role === 'owner' ? 'مالك' : 'مستخدم'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex space-x-2 space-x-reverse">
                      {user.isBanned ? (
                        <button
                          onClick={() => onUnbanUser(user.userId)}
                          className="px-3 py-1 bg-green-500 text-white rounded-lg text-sm hover:bg-green-600 transition-colors"
                        >
                          إلغاء الحظر
                        </button>
                      ) : (
                        <button
                          onClick={() => onBanUser(user.userId, "مخالفة قوانين المجتمع")}
                          className="px-3 py-1 bg-red-500 text-white rounded-lg text-sm hover:bg-red-600 transition-colors"
                        >
                          حظر
                        </button>
                      )}
                      
                      {user.role !== 'admin' && user.role !== 'owner' && (
                        <button
                          onClick={() => onPromoteToAdmin(user.userId)}
                          className="px-3 py-1 bg-purple-500 text-white rounded-lg text-sm hover:bg-purple-600 transition-colors"
                        >
                          ترقية لمدير
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function ContentTab({ posts, comments, onDeletePost, onDeleteComment }: any) {
  const [activeContentTab, setActiveContentTab] = useState("posts");
  const [searchTerm, setSearchTerm] = useState("");

  const filteredPosts = posts.filter((post: any) => 
    post.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredComments = comments.filter((comment: any) => 
    comment.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">إدارة المحتوى</h1>
      
      {/* Content Type Tabs */}
      <div className="flex space-x-4 space-x-reverse">
        <button
          onClick={() => setActiveContentTab("posts")}
          className={`px-6 py-3 rounded-xl font-semibold transition-all ${
            activeContentTab === "posts"
              ? "bg-blue-500 text-white shadow-lg"
              : "bg-gray-100 text-gray-600 hover:bg-gray-200"
          }`}
        >
          المنشورات ({posts.length})
        </button>
        <button
          onClick={() => setActiveContentTab("comments")}
          className={`px-6 py-3 rounded-xl font-semibold transition-all ${
            activeContentTab === "comments"
              ? "bg-blue-500 text-white shadow-lg"
              : "bg-gray-100 text-gray-600 hover:bg-gray-200"
          }`}
        >
          التعليقات ({comments.length})
        </button>
      </div>

      {/* Search */}
      <input
        type="text"
        placeholder={`البحث في ${activeContentTab === "posts" ? "المنشورات" : "التعليقات"}...`}
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none"
      />

      {/* Posts Tab */}
      {activeContentTab === "posts" && (
        <div className="space-y-4">
          {filteredPosts.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">📝</div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">لا توجد منشورات</h3>
              <p className="text-gray-600">لم يتم العثور على منشورات تطابق البحث</p>
            </div>
          ) : (
            filteredPosts.map((post: any) => (
              <div key={post._id} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3 space-x-reverse">
                    {post.author?.avatarUrl ? (
                      <img src={post.author.avatarUrl} alt="" className="w-12 h-12 rounded-full object-cover" />
                    ) : (
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                        <span className="text-white font-semibold">
                          {post.author?.firstName[0]}{post.author?.lastName[0]}
                        </span>
                      </div>
                    )}
                    <div>
                      <h3 className="font-bold text-gray-800">
                        {post.author?.firstName} {post.author?.lastName}
                      </h3>
                      <p className="text-sm text-gray-500">
                        {new Date(post._creationTime).toLocaleDateString('ar')}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      post.type === 'text' ? 'bg-blue-100 text-blue-800' :
                      post.type === 'image' ? 'bg-green-100 text-green-800' :
                      post.type === 'video' ? 'bg-purple-100 text-purple-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {post.type === 'text' ? 'نص' : 
                       post.type === 'image' ? 'صورة' :
                       post.type === 'video' ? 'فيديو' : post.type}
                    </span>
                    
                    <button
                      onClick={() => onDeletePost(post._id, "محتوى مخالف لقوانين المجتمع")}
                      className="px-3 py-1 bg-red-500 text-white rounded-lg text-sm hover:bg-red-600 transition-colors"
                    >
                      حذف
                    </button>
                  </div>
                </div>

                <div className="mb-4">
                  <p className="text-gray-800 mb-3">{post.content}</p>
                  
                  {post.mediaUrl && (
                    <div className="mt-3">
                      {post.type === 'image' ? (
                        <img src={post.mediaUrl} alt="" className="max-w-xs rounded-lg" />
                      ) : post.type === 'video' ? (
                        <video src={post.mediaUrl} controls className="max-w-xs rounded-lg" />
                      ) : null}
                    </div>
                  )}
                </div>

                <div className="flex items-center space-x-6 space-x-reverse text-sm text-gray-500">
                  <span className="flex items-center space-x-1 space-x-reverse">
                    <span>❤️</span>
                    <span>{post.likesCount} إعجاب</span>
                  </span>
                  <span className="flex items-center space-x-1 space-x-reverse">
                    <span>💬</span>
                    <span>{post.commentsCount} تعليق</span>
                  </span>
                  <span className="flex items-center space-x-1 space-x-reverse">
                    <span>👁️</span>
                    <span>{post.privacy === 'public' ? 'عام' : 'أصدقاء'}</span>
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Comments Tab */}
      {activeContentTab === "comments" && (
        <div className="space-y-4">
          {filteredComments.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">💬</div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">لا توجد تعليقات</h3>
              <p className="text-gray-600">لم يتم العثور على تعليقات تطابق البحث</p>
            </div>
          ) : (
            filteredComments.map((comment: any) => (
              <div key={comment._id} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3 space-x-reverse">
                    {comment.author?.avatarUrl ? (
                      <img src={comment.author.avatarUrl} alt="" className="w-10 h-10 rounded-full object-cover" />
                    ) : (
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                        <span className="text-white font-semibold text-sm">
                          {comment.author?.firstName[0]}{comment.author?.lastName[0]}
                        </span>
                      </div>
                    )}
                    <div>
                      <h4 className="font-semibold text-gray-800">
                        {comment.author?.firstName} {comment.author?.lastName}
                      </h4>
                      <p className="text-xs text-gray-500">
                        {new Date(comment._creationTime).toLocaleDateString('ar')}
                      </p>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => onDeleteComment(comment._id, "تعليق مخالف لقوانين المجتمع")}
                    className="px-3 py-1 bg-red-500 text-white rounded-lg text-sm hover:bg-red-600 transition-colors"
                  >
                    حذف
                  </button>
                </div>

                <div className="mb-3">
                  <p className="text-gray-800 mb-2">{comment.content}</p>
                  
                  {comment.post && (
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">
                        <span className="font-medium">تعليق على:</span> {comment.post.content}
                      </p>
                    </div>
                  )}
                </div>

                <div className="flex items-center space-x-4 space-x-reverse text-sm text-gray-500">
                  <span className="flex items-center space-x-1 space-x-reverse">
                    <span>❤️</span>
                    <span>{comment.likesCount} إعجاب</span>
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

function VerificationsTab({ verifications, onApprove, onReject }: any) {
  const [selectedRequest, setSelectedRequest] = useState<any>(null);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">طلبات التوثيق</h1>
      
      {verifications.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">✓</div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">لا توجد طلبات معلقة</h3>
          <p className="text-gray-600">جميع طلبات التوثيق تم مراجعتها</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {verifications.map((request: any) => (
            <div key={request._id} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
              <div className="flex items-start space-x-4 space-x-reverse mb-4">
                {request.user?.avatarUrl ? (
                  <img src={request.user.avatarUrl} alt="" className="w-16 h-16 rounded-full object-cover" />
                ) : (
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-semibold text-lg">
                      {request.user?.firstName[0]}{request.user?.lastName[0]}
                    </span>
                  </div>
                )}
                
                <div className="flex-1">
                  <h3 className="font-bold text-gray-800 text-lg">
                    {request.user?.firstName} {request.user?.lastName}
                  </h3>
                  <p className="text-gray-600">{request.user?.email}</p>
                  <p className="text-sm text-gray-500 mt-1">
                    طلب في {new Date(request._creationTime).toLocaleDateString('ar')}
                  </p>
                </div>
              </div>

              {request.reason && (
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-700 mb-2">سبب طلب التوثيق:</h4>
                  <p className="text-gray-600 bg-gray-50 p-3 rounded-lg">{request.reason}</p>
                </div>
              )}

              {request.socialLinks && request.socialLinks.length > 0 && (
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-700 mb-2">الروابط الاجتماعية:</h4>
                  <div className="space-y-1">
                    {request.socialLinks.map((link: string, index: number) => (
                      <a key={index} href={link} target="_blank" rel="noopener noreferrer" 
                         className="text-blue-500 hover:underline block text-sm">
                        {link}
                      </a>
                    ))}
                  </div>
                </div>
              )}

              {request.documentUrls && request.documentUrls.length > 0 && (
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-700 mb-2">المستندات المرفقة:</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {request.documentUrls.map((doc: any, index: number) => (
                      <img key={index} src={doc.url} alt={`Document ${index + 1}`} 
                           className="w-full h-24 object-cover rounded-lg cursor-pointer hover:opacity-80"
                           onClick={() => window.open(doc.url, '_blank')} />
                    ))}
                  </div>
                </div>
              )}

              <div className="flex space-x-3 space-x-reverse">
                <button
                  onClick={() => onApprove(request._id, "تم قبول الطلب بعد مراجعة المستندات")}
                  className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 text-white py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all font-semibold"
                >
                  قبول التوثيق
                </button>
                <button
                  onClick={() => onReject(request._id, "المستندات غير كافية للتوثيق")}
                  className="flex-1 bg-gradient-to-r from-red-500 to-pink-600 text-white py-3 rounded-xl hover:from-red-600 hover:to-pink-700 transition-all font-semibold"
                >
                  رفض الطلب
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function SiteSettingsTab({ settings, onUpdate }: any) {
  const [formData, setFormData] = useState({
    siteName: settings?.siteName || "YAK Social",
    primaryColor: settings?.primaryColor || "#3b82f6",
    accentColor: settings?.accentColor || "#10b981",
    maxUploadSize: settings?.maxUploadSize || 100,
    enableStories: settings?.enableStories ?? true,
    enableLiveStreaming: settings?.enableLiveStreaming ?? false,
    maintenanceMode: settings?.maintenanceMode ?? false,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await onUpdate({
        ...formData,
        maxUploadSize: formData.maxUploadSize * 1024 * 1024, // Convert MB to bytes
      });
      toast.success("تم حفظ إعدادات الموقع بنجاح");
    } catch (error) {
      toast.error("حدث خطأ أثناء حفظ الإعدادات");
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">إعدادات الموقع</h1>
      
      <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">اسم الموقع</label>
            <input
              type="text"
              value={formData.siteName}
              onChange={(e) => setFormData({ ...formData, siteName: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">الحد الأقصى لحجم الرفع (MB)</label>
            <input
              type="number"
              value={formData.maxUploadSize}
              onChange={(e) => setFormData({ ...formData, maxUploadSize: parseInt(e.target.value) })}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">اللون الأساسي</label>
            <div className="flex items-center space-x-3 space-x-reverse">
              <input
                type="color"
                value={formData.primaryColor}
                onChange={(e) => setFormData({ ...formData, primaryColor: e.target.value })}
                className="w-12 h-12 rounded-lg border border-gray-200"
              />
              <input
                type="text"
                value={formData.primaryColor}
                onChange={(e) => setFormData({ ...formData, primaryColor: e.target.value })}
                className="flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">اللون الثانوي</label>
            <div className="flex items-center space-x-3 space-x-reverse">
              <input
                type="color"
                value={formData.accentColor}
                onChange={(e) => setFormData({ ...formData, accentColor: e.target.value })}
                className="w-12 h-12 rounded-lg border border-gray-200"
              />
              <input
                type="text"
                value={formData.accentColor}
                onChange={(e) => setFormData({ ...formData, accentColor: e.target.value })}
                className="flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none"
              />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-800">ميزات الموقع</h3>
          
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
            <div>
              <h4 className="font-semibold text-gray-800">تفعيل القصص</h4>
              <p className="text-sm text-gray-600">السماح للمستخدمين بنشر القصص</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={formData.enableStories}
                onChange={(e) => setFormData({ ...formData, enableStories: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
            <div>
              <h4 className="font-semibold text-gray-800">تفعيل البث المباشر</h4>
              <p className="text-sm text-gray-600">السماح للمستخدمين بالبث المباشر</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={formData.enableLiveStreaming}
                onChange={(e) => setFormData({ ...formData, enableLiveStreaming: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between p-4 bg-red-50 rounded-xl border border-red-200">
            <div>
              <h4 className="font-semibold text-red-800">وضع الصيانة</h4>
              <p className="text-sm text-red-600">إيقاف الموقع مؤقتاً للصيانة</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={formData.maintenanceMode}
                onChange={(e) => setFormData({ ...formData, maintenanceMode: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-red-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-red-600"></div>
            </label>
          </div>
        </div>

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-4 rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all font-semibold text-lg"
        >
          حفظ الإعدادات
        </button>
      </form>
    </div>
  );
}

function AuditLogsTab({ logs }: { logs: any[] }) {
  const getActionIcon = (action: string) => {
    switch (action) {
      case "ban_user": return "🚫";
      case "unban_user": return "✅";
      case "promote_to_admin": return "⬆️";
      case "demote_from_admin": return "⬇️";
      case "approve_verification": return "✓";
      case "reject_verification": return "❌";
      case "delete_post": return "🗑️";
      case "delete_comment": return "💬🗑️";
      case "update_site_settings": return "⚙️";
      default: return "📝";
    }
  };

  const getActionText = (action: string) => {
    switch (action) {
      case "ban_user": return "حظر مستخدم";
      case "unban_user": return "إلغاء حظر مستخدم";
      case "promote_to_admin": return "ترقية إلى مدير";
      case "demote_from_admin": return "تنزيل من منصب مدير";
      case "approve_verification": return "قبول طلب توثيق";
      case "reject_verification": return "رفض طلب توثيق";
      case "delete_post": return "حذف منشور";
      case "delete_comment": return "حذف تعليق";
      case "update_site_settings": return "تحديث إعدادات الموقع";
      default: return action;
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">سجل العمليات</h1>
      
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="space-y-1">
          {logs.map((log) => (
            <div key={log._id} className="flex items-start space-x-4 space-x-reverse p-6 hover:bg-gray-50 border-b border-gray-100 last:border-b-0">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-lg">
                  {getActionIcon(log.action)}
                </div>
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="font-semibold text-gray-800">
                    {getActionText(log.action)}
                  </p>
                  <span className="text-sm text-gray-500">
                    {new Date(log._creationTime).toLocaleString('ar')}
                  </span>
                </div>
                
                <p className="text-sm text-gray-600 mt-1">
                  بواسطة: <span className="font-medium">{log.actorName}</span>
                </p>
                
                {log.details && (
                  <p className="text-sm text-gray-500 mt-2 bg-gray-50 p-2 rounded-lg">
                    {log.details}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
