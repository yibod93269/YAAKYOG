import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";
import { Id } from "../../convex/_generated/dataModel";

interface NotificationsProps {
  onUserClick?: (userId: Id<"users">) => void;
}

export function Notifications({ onUserClick }: NotificationsProps) {
  const notifications = useQuery(api.notifications.getNotifications) || [];
  const markAsRead = useMutation(api.notifications.markNotificationAsRead);
  const acceptFollowRequest = useMutation(api.follows.acceptFollowRequest);

  const handleMarkAsRead = async (notificationId: Id<"notifications">) => {
    try {
      await markAsRead({ notificationId });
    } catch (error) {
      console.error("Error marking notification as read:", error);
    }
  };

  const handleAcceptFollow = async (followerId: Id<"users">, notificationId: Id<"notifications">) => {
    try {
      await acceptFollowRequest({ followerId });
      await markAsRead({ notificationId });
      toast.success("تم قبول طلب المتابعة");
    } catch (error) {
      toast.error("حدث خطأ أثناء قبول الطلب");
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "follow_request":
        return "👤";
      case "follow_accepted":
        return "✅";
      case "like":
        return "❤️";
      case "comment":
        return "💬";
      case "group_invite":
        return "👥";
      default:
        return "🔔";
    }
  };

  const getNotificationText = (notification: any) => {
    const fromUserName = notification.fromUser
      ? `${notification.fromUser.firstName} ${notification.fromUser.lastName}`
      : "مستخدم";

    switch (notification.type) {
      case "follow_request":
        return `${fromUserName} يريد متابعتك`;
      case "follow_accepted":
        return `${fromUserName} قبل طلب متابعتك`;
      case "like":
        return `${fromUserName} أعجب بمنشورك`;
      case "comment":
        return `${fromUserName} علق على منشورك`;
      case "group_invite":
        return `${fromUserName} دعاك للانضمام لمجموعة`;
      default:
        return "إشعار جديد";
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-800">الإشعارات</h1>

      {notifications.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">🔔</div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">لا توجد إشعارات</h3>
          <p className="text-gray-600">ستظهر إشعاراتك هنا</p>
        </div>
      ) : (
        <div className="space-y-4">
          {notifications.map((notification) => (
            <div
              key={notification._id}
              className={`bg-white rounded-2xl shadow-sm border border-gray-100 p-4 transition-all hover:shadow-md ${
                !notification.isRead ? "border-blue-200 bg-blue-50" : ""
              }`}
              onClick={() => !notification.isRead && handleMarkAsRead(notification._id)}
            >
              <div className="flex items-start space-x-4 space-x-reverse">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center text-2xl">
                    {getNotificationIcon(notification.type)}
                  </div>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="text-gray-800 font-medium">
                        {getNotificationText(notification)}
                      </p>
                      <p className="text-sm text-gray-500 mt-1">
                        {formatDistanceToNow(new Date(notification._creationTime), {
                          addSuffix: true,
                          locale: ar,
                        })}
                      </p>
                    </div>

                    {!notification.isRead && (
                      <div className="w-3 h-3 bg-blue-500 rounded-full flex-shrink-0"></div>
                    )}
                  </div>

                  {/* Follow Request Actions */}
                  {notification.type === "follow_request" && !notification.isRead && notification.fromUserId && (
                    <div className="flex space-x-3 space-x-reverse mt-3">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleAcceptFollow(notification.fromUserId!, notification._id);
                        }}
                        className="px-4 py-2 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-xl text-sm hover:from-blue-600 hover:to-green-600 transition-all"
                      >
                        قبول
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleMarkAsRead(notification._id);
                        }}
                        className="px-4 py-2 border border-gray-300 text-gray-700 rounded-xl text-sm hover:bg-gray-50 transition-colors"
                      >
                        تجاهل
                      </button>
                    </div>
                  )}

                  {/* User Avatar */}
                  {notification.fromUser && (
                    <div 
                      className="flex items-center space-x-3 space-x-reverse mt-3 cursor-pointer hover:bg-gray-50 p-2 rounded-lg transition-colors"
                      onClick={() => onUserClick?.(notification.fromUserId!)}
                    >
                      {notification.fromUser.avatarUrl ? (
                        <img
                          src={notification.fromUser.avatarUrl}
                          alt={`${notification.fromUser.firstName} ${notification.fromUser.lastName}`}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                      ) : (
                        <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                          <span className="text-white text-sm font-semibold">
                            {notification.fromUser.firstName[0]}
                          </span>
                        </div>
                      )}
                      <span className="text-sm text-gray-600">
                        {notification.fromUser.firstName} {notification.fromUser.lastName}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
