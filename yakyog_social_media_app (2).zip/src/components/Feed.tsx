import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { PostCard } from "./PostCard";
import { StoriesBar } from "./StoriesBar";
import { CreatePost } from "./CreatePost";
import { Id } from "../../convex/_generated/dataModel";

interface FeedProps {
  onUserClick?: (userId: Id<"users">) => void;
}

export function Feed({ onUserClick }: FeedProps) {
  const posts = useQuery(api.posts.getFeed) || [];
  const stories = useQuery(api.posts.getStories) || [];

  return (
    <div className="space-y-6">
      {/* Create Post */}
      <CreatePost />
      
      {/* Stories Section */}
      <StoriesBar />

      {/* Posts Feed */}
      <div className="space-y-6">
        {posts.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📱</div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">لا توجد منشورات بعد</h3>
            <p className="text-gray-600">ابدأ بمتابعة أشخاص لرؤية منشوراتهم هنا</p>
          </div>
        ) : (
          posts.map((post) => (
            <PostCard key={post._id} post={post} onUserClick={onUserClick} />
          ))
        )}
      </div>
    </div>
  );
}
