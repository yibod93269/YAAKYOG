import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: any) => void;
}

export function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const profile = useQuery(api.profiles.getProfile, {});
  const unreadCount = useQuery(api.notifications.getUnreadCount) || 0;

  const menuItems = [
    {
      id: "feed",
      label: "🏠 الرئيسية",
      icon: "🏠",
    },
    {
      id: "search",
      label: "🔍 البحث",
      icon: "🔍",
    },
    {
      id: "messages",
      label: "💬 الرسائل",
      icon: "💬",
    },
    {
      id: "groups",
      label: "👥 المجموعات",
      icon: "👥",
    },
    {
      id: "notifications",
      label: "🔔 الإشعارات",
      icon: "🔔",
      badge: unreadCount > 0 ? unreadCount : undefined,
    },
    {
      id: "profile",
      label: "👤 الملف الشخصي",
      icon: "👤",
    },
    {
      id: "settings",
      label: "⚙️ الإعدادات",
      icon: "⚙️",
    },
  ];

  return (
    <>
      {/* Mobile Bottom Navigation */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50">
        <div className="flex justify-around py-2">
          {menuItems.slice(0, 5).map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center p-2 rounded-lg transition-colors relative ${
                activeTab === item.id
                  ? "text-blue-600 bg-blue-50"
                  : "text-gray-600 hover:text-blue-600 hover:bg-gray-50"
              }`}
            >
              <span className="text-xl mb-1">{item.icon}</span>
              <span className="text-xs font-medium">{item.label}</span>
              {item.badge && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {item.badge}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Desktop Sidebar */}
      <div className="hidden lg:block fixed left-0 top-0 h-full w-64 bg-white border-r border-gray-200 z-40">
        <div className="p-6 pt-20">
          {/* User Profile Section */}
          {profile && (
            <div className="mb-8 p-4 bg-gradient-to-r from-blue-50 to-green-50 rounded-xl">
              <div className="flex items-center space-x-3 space-x-reverse">
                <div className="relative">
                  {profile.avatarUrl ? (
                    <img
                      src={profile.avatarUrl}
                      alt="Profile"
                      className="w-12 h-12 rounded-full object-cover"
                    />
                  ) : (
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                      <span className="text-white font-semibold">
                        {profile.firstName[0]}{profile.lastName[0]}
                      </span>
                    </div>
                  )}
                  <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${
                    profile.isOnline ? "bg-green-500" : "bg-red-500"
                  }`}></div>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-gray-800 truncate">
                    {profile.firstName} {profile.lastName}
                  </p>
                  <p className="text-sm text-gray-600 truncate">{profile.email}</p>
                </div>
              </div>
            </div>
          )}

          {/* Navigation Menu */}
          <nav className="space-y-2">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center space-x-3 space-x-reverse p-3 rounded-xl transition-all duration-200 relative ${
                  activeTab === item.id
                    ? "bg-gradient-to-r from-blue-500 to-green-500 text-white shadow-lg"
                    : "text-gray-700 hover:bg-gray-100"
                }`}
              >
                <span className="text-xl">{item.icon}</span>
                <span className="font-medium">{item.label}</span>
                {item.badge && (
                  <span className="absolute left-3 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>
      </div>
    </>
  );
}
