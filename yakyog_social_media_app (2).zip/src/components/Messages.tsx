import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

export function Messages() {
  const [selectedConversation, setSelectedConversation] = useState<any>(null);
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const conversations = useQuery(api.messages.getConversations) || [];
  const messages = useQuery(
    api.messages.getConversation,
    selectedConversation ? { otherUserId: selectedConversation.otherUserId } : "skip"
  ) || [];

  const sendMessage = useMutation(api.messages.sendDirectMessage);
  const markAsRead = useMutation(api.messages.markMessagesAsRead);

  const handleSelectConversation = async (conversation: any) => {
    setSelectedConversation(conversation);
    if (conversation.unreadCount > 0) {
      await markAsRead({ otherUserId: conversation.otherUserId });
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !selectedConversation) return;

    setIsLoading(true);
    try {
      await sendMessage({
        receiverId: selectedConversation.otherUserId,
        content: message.trim(),
        type: "text",
      });
      setMessage("");
    } catch (error) {
      toast.error("حدث خطأ أثناء إرسال الرسالة");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-[calc(100vh-8rem)] bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      {/* Conversations List */}
      <div className="w-1/3 border-r border-gray-200">
        <div className="p-4 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-800">الرسائل</h2>
        </div>
        
        <div className="overflow-y-auto h-full">
          {conversations.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-4xl mb-4">💬</div>
              <p className="text-gray-600">لا توجد محادثات بعد</p>
            </div>
          ) : (
            conversations.map((conversation) => (
              <button
                key={conversation.otherUserId}
                onClick={() => handleSelectConversation(conversation)}
                className={`w-full p-4 border-b border-gray-100 hover:bg-gray-50 transition-colors text-right ${
                  selectedConversation?.otherUserId === conversation.otherUserId
                    ? "bg-blue-50 border-blue-200"
                    : ""
                }`}
              >
                <div className="flex items-center space-x-3 space-x-reverse">
                  <div className="relative">
                    {conversation.otherUser?.avatarUrl ? (
                      <img
                        src={conversation.otherUser.avatarUrl}
                        alt={`${conversation.otherUser.firstName} ${conversation.otherUser.lastName}`}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                    ) : (
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                        <span className="text-white font-semibold">
                          {conversation.otherUser?.firstName[0]}
                        </span>
                      </div>
                    )}
                    <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${
                      conversation.otherUser?.isOnline ? "bg-green-500" : "bg-red-500"
                    }`}></div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold text-gray-800 truncate">
                        {conversation.otherUser?.firstName} {conversation.otherUser?.lastName}
                      </h3>
                      {conversation.unreadCount > 0 && (
                        <span className="bg-blue-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                          {conversation.unreadCount}
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 truncate text-right">
                      {conversation.lastMessage.content}
                    </p>
                    <p className="text-xs text-gray-500 text-right">
                      {formatDistanceToNow(new Date(conversation.lastMessage._creationTime), {
                        addSuffix: true,
                        locale: ar,
                      })}
                    </p>
                  </div>
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {selectedConversation ? (
          <>
            {/* Chat Header */}
            <div className="p-4 border-b border-gray-200 flex items-center space-x-3 space-x-reverse">
              <div className="relative">
                {selectedConversation.otherUser?.avatarUrl ? (
                  <img
                    src={selectedConversation.otherUser.avatarUrl}
                    alt={`${selectedConversation.otherUser.firstName} ${selectedConversation.otherUser.lastName}`}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-semibold">
                      {selectedConversation.otherUser?.firstName[0]}
                    </span>
                  </div>
                )}
                <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${
                  selectedConversation.otherUser?.isOnline ? "bg-green-500" : "bg-red-500"
                }`}></div>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">
                  {selectedConversation.otherUser?.firstName} {selectedConversation.otherUser?.lastName}
                </h3>
                <p className="text-sm text-gray-600">
                  {selectedConversation.otherUser?.isOnline ? "متصل الآن" : "غير متصل"}
                </p>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((msg) => (
                <div
                  key={msg._id}
                  className={`flex ${
                    msg.senderId === selectedConversation.otherUserId
                      ? "justify-start"
                      : "justify-end"
                  }`}
                >
                  <div
                    className={`max-w-xs lg:max-w-md px-4 py-2 rounded-2xl ${
                      msg.senderId === selectedConversation.otherUserId
                        ? "bg-gray-200 text-gray-800"
                        : "bg-gradient-to-r from-blue-500 to-green-500 text-white"
                    }`}
                  >
                    <p>{msg.content}</p>
                    <p
                      className={`text-xs mt-1 ${
                        msg.senderId === selectedConversation.otherUserId
                          ? "text-gray-500"
                          : "text-white text-opacity-70"
                      }`}
                    >
                      {formatDistanceToNow(new Date(msg._creationTime), {
                        addSuffix: true,
                        locale: ar,
                      })}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Message Input */}
            <form onSubmit={handleSendMessage} className="p-4 border-t border-gray-200">
              <div className="flex space-x-3 space-x-reverse">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="اكتب رسالة..."
                  className="flex-1 px-4 py-2 rounded-full border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none"
                />
                <button
                  type="submit"
                  disabled={!message.trim() || isLoading}
                  className="bg-gradient-to-r from-blue-500 to-green-500 text-white px-6 py-2 rounded-full hover:from-blue-600 hover:to-green-600 transition-all disabled:opacity-50"
                >
                  إرسال
                </button>
              </div>
            </form>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <div className="text-6xl mb-4">💬</div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">اختر محادثة</h3>
              <p className="text-gray-600">اختر محادثة من القائمة لبدء المراسلة</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
