import { useState, useRef, useEffect } from "react";

interface MediaPlayerProps {
  src: string;
  type: "image" | "video";
  originalWidth?: number;
  originalHeight?: number;
  poster?: string;
  className?: string;
}

export function MediaPlayer({ 
  src, 
  type, 
  originalWidth, 
  originalHeight, 
  poster, 
  className = "" 
}: MediaPlayerProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [isOriginalSize, setIsOriginalSize] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video || type !== "video") return;

    const updateTime = () => setCurrentTime(video.currentTime);
    const updateDuration = () => setDuration(video.duration);
    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);

    video.addEventListener("timeupdate", updateTime);
    video.addEventListener("loadedmetadata", updateDuration);
    video.addEventListener("play", handlePlay);
    video.addEventListener("pause", handlePause);

    return () => {
      video.removeEventListener("timeupdate", updateTime);
      video.removeEventListener("loadedmetadata", updateDuration);
      video.removeEventListener("play", handlePlay);
      video.removeEventListener("pause", handlePause);
    };
  }, [type]);

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.pause();
    } else {
      video.play();
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const video = videoRef.current;
    if (!video) return;

    const time = (parseFloat(e.target.value) / 100) * duration;
    video.currentTime = time;
    setCurrentTime(time);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const video = videoRef.current;
    if (!video) return;

    const newVolume = parseFloat(e.target.value) / 100;
    video.volume = newVolume;
    setVolume(newVolume);
  };

  const changePlaybackRate = (rate: number) => {
    const video = videoRef.current;
    if (!video) return;

    video.playbackRate = rate;
    setPlaybackRate(rate);
  };

  const toggleFullscreen = () => {
    const container = containerRef.current;
    if (!container) return;

    if (!isFullscreen) {
      if (container.requestFullscreen) {
        container.requestFullscreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
    setIsFullscreen(!isFullscreen);
  };

  const toggleOriginalSize = () => {
    setIsOriginalSize(!isOriginalSize);
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  };

  const getMediaStyle = () => {
    if (isOriginalSize && originalWidth && originalHeight) {
      return {
        width: `${originalWidth}px`,
        height: `${originalHeight}px`,
        maxWidth: "100vw",
        maxHeight: "100vh",
        objectFit: "contain" as const,
      };
    }
    return {
      width: "100%",
      height: "auto",
      maxWidth: "100%",
      objectFit: "contain" as const,
    };
  };

  if (type === "image") {
    return (
      <div className={`relative group ${className}`} ref={containerRef}>
        <img
          src={src}
          alt="Media content"
          style={getMediaStyle()}
          className="rounded-xl cursor-pointer transition-transform hover:scale-105"
          onClick={toggleFullscreen}
        />
        
        {/* Image Controls Overlay */}
        <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="flex space-x-2 space-x-reverse">
            <button
              onClick={toggleOriginalSize}
              className="bg-black bg-opacity-50 text-white p-2 rounded-full hover:bg-opacity-70 transition-all"
              title={isOriginalSize ? "تصغير للشاشة" : "عرض بالحجم الأصلي"}
            >
              {isOriginalSize ? "📱" : "🔍"}
            </button>
            <button
              onClick={toggleFullscreen}
              className="bg-black bg-opacity-50 text-white p-2 rounded-full hover:bg-opacity-70 transition-all"
              title="شاشة كاملة"
            >
              ⛶
            </button>
          </div>
        </div>

        {/* Original Size Info */}
        {originalWidth && originalHeight && (
          <div className="absolute bottom-4 left-4 bg-black bg-opacity-50 text-white px-3 py-1 rounded-full text-sm opacity-0 group-hover:opacity-100 transition-opacity">
            {originalWidth} × {originalHeight}
          </div>
        )}
      </div>
    );
  }

  return (
    <div 
      className={`relative bg-black rounded-xl overflow-hidden ${className}`}
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={() => setShowControls(false)}
    >
      <video
        ref={videoRef}
        src={src}
        poster={poster}
        style={getMediaStyle()}
        className="w-full h-auto"
        onClick={togglePlay}
        onDoubleClick={toggleFullscreen}
      />

      {/* Video Controls */}
      <div className={`absolute inset-0 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        {/* Play/Pause Overlay */}
        <div className="absolute inset-0 flex items-center justify-center">
          <button
            onClick={togglePlay}
            className="bg-black bg-opacity-50 text-white p-4 rounded-full hover:bg-opacity-70 transition-all transform hover:scale-110"
          >
            {isPlaying ? "⏸️" : "▶️"}
          </button>
        </div>

        {/* Top Controls */}
        <div className="absolute top-4 right-4 flex space-x-2 space-x-reverse">
          <button
            onClick={toggleOriginalSize}
            className="bg-black bg-opacity-50 text-white p-2 rounded-full hover:bg-opacity-70 transition-all"
            title={isOriginalSize ? "تصغير للشاشة" : "عرض بالحجم الأصلي"}
          >
            {isOriginalSize ? "📱" : "🔍"}
          </button>
          
          {/* Playback Speed */}
          <div className="relative group">
            <button className="bg-black bg-opacity-50 text-white p-2 rounded-full hover:bg-opacity-70 transition-all">
              {playbackRate}x
            </button>
            <div className="absolute top-full right-0 mt-2 bg-black bg-opacity-80 rounded-lg p-2 opacity-0 group-hover:opacity-100 transition-opacity">
              {[0.5, 0.75, 1, 1.25, 1.5, 2].map((rate) => (
                <button
                  key={rate}
                  onClick={() => changePlaybackRate(rate)}
                  className={`block w-full text-left px-3 py-1 text-white hover:bg-white hover:bg-opacity-20 rounded ${
                    playbackRate === rate ? 'bg-white bg-opacity-20' : ''
                  }`}
                >
                  {rate}x
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={toggleFullscreen}
            className="bg-black bg-opacity-50 text-white p-2 rounded-full hover:bg-opacity-70 transition-all"
            title="شاشة كاملة"
          >
            ⛶
          </button>
        </div>

        {/* Bottom Controls */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
          {/* Progress Bar */}
          <div className="mb-3">
            <input
              type="range"
              min="0"
              max="100"
              value={duration ? (currentTime / duration) * 100 : 0}
              onChange={handleSeek}
              className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer slider"
            />
          </div>

          <div className="flex items-center justify-between text-white">
            <div className="flex items-center space-x-4 space-x-reverse">
              <button
                onClick={togglePlay}
                className="hover:text-blue-400 transition-colors"
              >
                {isPlaying ? "⏸️" : "▶️"}
              </button>

              <span className="text-sm">
                {formatTime(currentTime)} / {formatTime(duration)}
              </span>

              {/* Volume Control */}
              <div className="flex items-center space-x-2 space-x-reverse">
                <button
                  onClick={() => handleVolumeChange({ target: { value: volume > 0 ? "0" : "100" } } as any)}
                  className="hover:text-blue-400 transition-colors"
                >
                  {volume === 0 ? "🔇" : volume < 0.5 ? "🔉" : "🔊"}
                </button>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={volume * 100}
                  onChange={handleVolumeChange}
                  className="w-20 h-1 bg-gray-600 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            </div>

            {/* Original Size Info */}
            {originalWidth && originalHeight && (
              <div className="text-sm opacity-75">
                {originalWidth} × {originalHeight}
              </div>
            )}
          </div>
        </div>
      </div>

      <style>{`
        .slider::-webkit-slider-thumb {
          appearance: none;
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: #3b82f6;
          cursor: pointer;
          border: 2px solid white;
          box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        
        .slider::-moz-range-thumb {
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: #3b82f6;
          cursor: pointer;
          border: 2px solid white;
          box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
      `}</style>
    </div>
  );
}
