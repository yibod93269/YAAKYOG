import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function CreatePost() {
  const [content, setContent] = useState("");
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string | null>(null);
  const [postType, setPostType] = useState<"text" | "image" | "video" | "story" | "yogo">("text");
  const [privacy, setPrivacy] = useState<"public" | "friends">("public");
  const [isYogo, setIsYogo] = useState(false);
  const [yogoType, setYogoType] = useState<"public" | "friends">("public");
  const [isLoading, setIsLoading] = useState(false);

  const createPost = useMutation(api.posts.createPost);
  const generateUploadUrl = useMutation(api.posts.generateUploadUrl);

  const handleMediaSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setMediaFile(file);
      const reader = new FileReader();
      reader.onload = (e) => setMediaPreview(e.target?.result as string);
      reader.readAsDataURL(file);
      
      // Auto-detect post type based on file
      if (file.type.startsWith("image/")) {
        setPostType("image");
      } else if (file.type.startsWith("video/")) {
        setPostType("video");
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() && !mediaFile) {
      toast.error("يرجى إضافة محتوى أو وسائط");
      return;
    }

    setIsLoading(true);
    try {
      let mediaId = undefined;

      // Upload media if selected
      if (mediaFile) {
        const uploadUrl = await generateUploadUrl();
        const result = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": mediaFile.type },
          body: mediaFile,
        });

        if (!result.ok) {
          throw new Error("فشل في رفع الوسائط");
        }

        const { storageId } = await result.json();
        mediaId = storageId;
      }

      await createPost({
        content: content.trim(),
        type: postType,
        mediaId,
        privacy,
        isYogo,
        yogoType: isYogo ? yogoType : undefined,
      });

      // Reset form
      setContent("");
      setMediaFile(null);
      setMediaPreview(null);
      setPostType("text");
      setPrivacy("public");
      setIsYogo(false);
      setYogoType("public");

      toast.success(
        postType === "story" ? "تم نشر القصة بنجاح!" :
        isYogo ? "تم نشر YOGO بنجاح!" :
        "تم نشر المنشور بنجاح!"
      );
    } catch (error) {
      toast.error("حدث خطأ أثناء النشر");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const removeMedia = () => {
    setMediaFile(null);
    setMediaPreview(null);
    setPostType("text");
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Post Type Selector */}
        <div className="flex space-x-2 space-x-reverse mb-4">
          <button
            type="button"
            onClick={() => setPostType("text")}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
              postType === "text" ? "bg-blue-500 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            📝 منشور
          </button>
          <button
            type="button"
            onClick={() => setPostType("story")}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
              postType === "story" ? "bg-purple-500 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            📖 قصة
          </button>
          <button
            type="button"
            onClick={() => { setPostType("yogo"); setIsYogo(true); }}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
              isYogo ? "bg-green-500 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            🎯 YOGO
          </button>
        </div>

        {/* Content Input */}
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder={
            postType === "story" ? "شارك قصتك..." :
            isYogo ? "شارك YOGO الخاص بك..." :
            "ما الذي تفكر فيه؟"
          }
          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none resize-none"
          rows={3}
        />

        {/* Media Preview */}
        {mediaPreview && (
          <div className="relative">
            {postType === "image" && (
              <img
                src={mediaPreview}
                alt="Preview"
                className="w-full h-64 object-cover rounded-xl"
              />
            )}
            {postType === "video" && (
              <video
                src={mediaPreview}
                className="w-full h-64 object-cover rounded-xl"
                controls
              />
            )}
            <button
              type="button"
              onClick={removeMedia}
              className="absolute top-2 right-2 bg-red-500 text-white rounded-full w-8 h-8 flex items-center justify-center hover:bg-red-600 transition-colors"
            >
              ✕
            </button>
          </div>
        )}

        {/* Privacy and Options */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 space-x-reverse">
            {/* Media Upload */}
            <label className="cursor-pointer text-blue-500 hover:text-blue-600 transition-colors">
              <span className="text-2xl">📷</span>
              <input
                type="file"
                accept="image/*,video/*"
                onChange={handleMediaSelect}
                className="hidden"
              />
            </label>

            {/* Privacy Selector */}
            <select
              value={privacy}
              onChange={(e) => setPrivacy(e.target.value as "public" | "friends")}
              className="px-3 py-2 rounded-lg border border-gray-200 focus:border-blue-500 outline-none text-sm"
            >
              <option value="public">🌍 عام</option>
              <option value="friends">👥 الأصدقاء فقط</option>
            </select>

            {/* YOGO Type Selector */}
            {isYogo && (
              <select
                value={yogoType}
                onChange={(e) => setYogoType(e.target.value as "public" | "friends")}
                className="px-3 py-2 rounded-lg border border-gray-200 focus:border-blue-500 outline-none text-sm"
              >
                <option value="public">🎯 YOGO عام</option>
                <option value="friends">🎯 YOGO للأصدقاء</option>
              </select>
            )}
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading || (!content.trim() && !mediaFile)}
            className="bg-gradient-to-r from-blue-500 to-green-500 text-white px-6 py-2 rounded-xl hover:from-blue-600 hover:to-green-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <div className="flex items-center space-x-2 space-x-reverse">
                <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                <span>جاري النشر...</span>
              </div>
            ) : (
              postType === "story" ? "نشر القصة" :
              isYogo ? "نشر YOGO" :
              "نشر"
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
