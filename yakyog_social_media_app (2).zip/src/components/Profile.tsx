import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function Profile() {
  const [isEditing, setIsEditing] = useState(false);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [bio, setBio] = useState("");
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  const profile = useQuery(api.profiles.getProfile, {});
  const followers = useQuery(api.follows.getFollowers, {}) || [];
  const following = useQuery(api.follows.getFollowing, {}) || [];
  
  const updateProfile = useMutation(api.profiles.updateProfile);
  const generateUploadUrl = useMutation(api.profiles.generateUploadUrl);

  const handleEditClick = () => {
    if (profile) {
      setFirstName(profile.firstName);
      setLastName(profile.lastName);
      setBio(profile.bio || "");
      setIsEditing(true);
    }
  };

  const handleAvatarSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAvatarFile(file);
      const reader = new FileReader();
      reader.onload = (e) => setAvatarPreview(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async () => {
    if (!firstName.trim() || !lastName.trim()) {
      toast.error("يرجى ملء الاسم الأول واسم العائلة");
      return;
    }

    setIsUploading(true);
    try {
      let avatarId = undefined;

      // Upload avatar if selected
      if (avatarFile) {
        const uploadUrl = await generateUploadUrl();
        const result = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": avatarFile.type },
          body: avatarFile,
        });

        if (!result.ok) {
          throw new Error("فشل في رفع الصورة");
        }

        const { storageId } = await result.json();
        avatarId = storageId;
      }

      await updateProfile({
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        bio: bio.trim() || undefined,
        avatar: avatarId,
      });

      toast.success("تم تحديث الملف الشخصي بنجاح!");
      setIsEditing(false);
      setAvatarFile(null);
      setAvatarPreview(null);
    } catch (error) {
      toast.error("حدث خطأ أثناء تحديث الملف الشخصي");
      console.error(error);
    } finally {
      setIsUploading(false);
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
    setAvatarFile(null);
    setAvatarPreview(null);
    setFirstName("");
    setLastName("");
    setBio("");
  };

  if (!profile) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Profile Header */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
        <div className="text-center">
          <div className="relative inline-block mb-6">
            {isEditing && avatarPreview ? (
              <img
                src={avatarPreview}
                alt="Preview"
                className="w-32 h-32 rounded-full object-cover"
              />
            ) : profile.avatarUrl ? (
              <img
                src={profile.avatarUrl}
                alt="Profile"
                className="w-32 h-32 rounded-full object-cover"
              />
            ) : (
              <div className="w-32 h-32 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold text-4xl">
                  {profile.firstName[0]}{profile.lastName[0]}
                </span>
              </div>
            )}
            
            <div className={`absolute -bottom-2 -right-2 w-8 h-8 rounded-full border-4 border-white ${
              profile.isOnline ? "bg-green-500" : "bg-red-500"
            }`}></div>

            {isEditing && (
              <label className="absolute bottom-0 right-0 bg-blue-500 text-white rounded-full w-10 h-10 flex items-center justify-center cursor-pointer hover:bg-blue-600 transition-colors">
                📷
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarSelect}
                  className="hidden"
                />
              </label>
            )}
          </div>

          {isEditing ? (
            <div className="space-y-4 mb-6">
              <div className="flex space-x-4 space-x-reverse">
                <input
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  placeholder="الاسم الأول"
                  className="flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none"
                />
                <input
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder="اسم العائلة"
                  className="flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none"
                />
              </div>
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="نبذة عنك..."
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none resize-none"
                rows={3}
              />
            </div>
          ) : (
            <>
              <h1 className="text-3xl font-bold text-gray-800 mb-2">
                {profile.firstName} {profile.lastName}
              </h1>
              <p className="text-gray-600 mb-2">{profile.email}</p>
              <p className="text-gray-600 mb-4">
                {profile.isOnline ? "متصل الآن" : "غير متصل"}
              </p>
              {profile.bio && (
                <p className="text-gray-700 mb-6">{profile.bio}</p>
              )}
            </>
          )}

          {/* Stats */}
          <div className="flex justify-center space-x-12 space-x-reverse mb-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-gray-800">{followers.length}</p>
              <p className="text-gray-600">متابع</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-gray-800">{following.length}</p>
              <p className="text-gray-600">يتابع</p>
            </div>
          </div>

          {/* Action Buttons */}
          {isEditing ? (
            <div className="flex space-x-4 space-x-reverse">
              <button
                onClick={handleCancel}
                className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors"
              >
                إلغاء
              </button>
              <button
                onClick={handleSave}
                disabled={isUploading}
                className="flex-1 bg-gradient-to-r from-blue-500 to-green-500 text-white px-6 py-3 rounded-xl hover:from-blue-600 hover:to-green-600 transition-all disabled:opacity-50"
              >
                {isUploading ? (
                  <div className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent mr-2"></div>
                    جاري الحفظ...
                  </div>
                ) : (
                  "حفظ التغييرات"
                )}
              </button>
            </div>
          ) : (
            <button
              onClick={handleEditClick}
              className="bg-gradient-to-r from-blue-500 to-green-500 text-white px-8 py-3 rounded-xl hover:from-blue-600 hover:to-green-600 transition-all"
            >
              تعديل الملف الشخصي
            </button>
          )}
        </div>
      </div>

      {/* Followers & Following */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Followers */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-4">المتابعون</h2>
          {followers.length === 0 ? (
            <p className="text-gray-600 text-center py-4">لا يوجد متابعون بعد</p>
          ) : (
            <div className="space-y-3">
              {followers.filter(Boolean).slice(0, 5).map((follower) => {
                if (!follower) return null;
                return (
                  <div key={follower.userId} className="flex items-center space-x-3 space-x-reverse">
                    {follower.avatarUrl ? (
                      <img
                        src={follower.avatarUrl}
                        alt={`${follower.firstName} ${follower.lastName}`}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                    ) : (
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                        <span className="text-white font-semibold text-sm">
                          {follower.firstName[0]}
                        </span>
                      </div>
                    )}
                    <div className="flex-1">
                      <p className="font-medium text-gray-800">
                        {follower.firstName} {follower.lastName}
                      </p>
                    </div>
                  </div>
                );
              })}
              {followers.length > 5 && (
                <p className="text-sm text-gray-500 text-center">
                  و {followers.length - 5} آخرين
                </p>
              )}
            </div>
          )}
        </div>

        {/* Following */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-4">يتابع</h2>
          {following.length === 0 ? (
            <p className="text-gray-600 text-center py-4">لا يتابع أحداً بعد</p>
          ) : (
            <div className="space-y-3">
              {following.filter(Boolean).slice(0, 5).map((followedUser) => {
                if (!followedUser) return null;
                return (
                  <div key={followedUser.userId} className="flex items-center space-x-3 space-x-reverse">
                    {followedUser.avatarUrl ? (
                      <img
                        src={followedUser.avatarUrl}
                        alt={`${followedUser.firstName} ${followedUser.lastName}`}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                    ) : (
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                        <span className="text-white font-semibold text-sm">
                          {followedUser.firstName[0]}
                        </span>
                      </div>
                    )}
                    <div className="flex-1">
                      <p className="font-medium text-gray-800">
                        {followedUser.firstName} {followedUser.lastName}
                      </p>
                    </div>
                  </div>
                );
              })}
              {following.length > 5 && (
                <p className="text-sm text-gray-500 text-center">
                  و {following.length - 5} آخرين
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
