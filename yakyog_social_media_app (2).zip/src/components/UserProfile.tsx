import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../../convex/_generated/dataModel";

interface UserProfileProps {
  userId: Id<"users">;
  onBack: () => void;
  onUserClick: (userId: Id<"users">) => void;
}

export function UserProfile({ userId, onBack, onUserClick }: UserProfileProps) {
  const profile = useQuery(api.profiles.getProfile, { userId });
  const posts = useQuery(api.posts.getUserPosts, { userId }) || [];
  const followers = useQuery(api.follows.getFollowers, { userId }) || [];
  const following = useQuery(api.follows.getFollowing, { userId }) || [];
  const followStatus = useQuery(api.follows.getFollowStatus, { userId });
  const currentUser = useQuery(api.profiles.getProfile, {});

  const followUser = useMutation(api.follows.followUser);
  const unfollowUser = useMutation(api.follows.unfollowUser);

  const handleFollow = async () => {
    try {
      await followUser({ userId });
      toast.success("تم إرسال طلب المتابعة");
    } catch (error) {
      toast.error("حدث خطأ أثناء إرسال الطلب");
    }
  };

  const handleUnfollow = async () => {
    try {
      await unfollowUser({ userId });
      toast.success("تم إلغاء المتابعة");
    } catch (error) {
      toast.error("حدث خطأ أثناء إلغاء المتابعة");
    }
  };

  const getFollowButton = () => {
    if (userId === currentUser?.userId) return null;

    switch (followStatus) {
      case "pending":
        return (
          <button
            onClick={handleUnfollow}
            className="px-6 py-3 border border-yellow-500 text-yellow-600 rounded-xl hover:bg-yellow-50 transition-colors"
          >
            قيد الانتظار
          </button>
        );
      case "accepted":
        return (
          <button
            onClick={handleUnfollow}
            className="px-6 py-3 border border-red-500 text-red-600 rounded-xl hover:bg-red-50 transition-colors"
          >
            إلغاء المتابعة
          </button>
        );
      default:
        return (
          <button
            onClick={handleFollow}
            className="px-6 py-3 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-xl hover:from-blue-600 hover:to-green-600 transition-all"
          >
            متابعة
          </button>
        );
    }
  };

  if (!profile) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="flex items-center space-x-2 space-x-reverse text-gray-600 hover:text-gray-800 transition-colors"
      >
        <span>←</span>
        <span>العودة</span>
      </button>

      {/* Profile Header */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
        <div className="text-center">
          <div className="relative inline-block mb-6">
            {profile.avatarUrl ? (
              <img
                src={profile.avatarUrl}
                alt="Profile"
                className="w-32 h-32 rounded-full object-cover"
              />
            ) : (
              <div className="w-32 h-32 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold text-4xl">
                  {profile.firstName[0]}{profile.lastName[0]}
                </span>
              </div>
            )}
            
            <div className={`absolute -bottom-2 -right-2 w-8 h-8 rounded-full border-4 border-white ${
              profile.isOnline ? "bg-green-500" : "bg-red-500"
            }`}></div>
          </div>

          <div className="flex items-center justify-center space-x-2 space-x-reverse mb-2">
            <h1 className="text-3xl font-bold text-gray-800">
              {profile.firstName} {profile.lastName}
            </h1>
            {profile.isVerified && (
              <span className="text-blue-500 text-2xl">✓</span>
            )}
          </div>
          
          <p className="text-gray-600 mb-2">{profile.email}</p>
          <p className="text-gray-600 mb-4">
            {profile.isOnline ? "متصل الآن" : "غير متصل"}
          </p>
          
          {profile.bio && (
            <p className="text-gray-700 mb-6">{profile.bio}</p>
          )}

          {/* Stats */}
          <div className="flex justify-center space-x-12 space-x-reverse mb-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-gray-800">{posts.length}</p>
              <p className="text-gray-600">منشور</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-gray-800">{followers.length}</p>
              <p className="text-gray-600">متابع</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-gray-800">{following.length}</p>
              <p className="text-gray-600">يتابع</p>
            </div>
          </div>

          {/* Follow Button */}
          {getFollowButton()}
        </div>
      </div>

      {/* User Posts */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h2 className="text-xl font-bold text-gray-800 mb-4">المنشورات</h2>
        
        {posts.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📝</div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">لا توجد منشورات</h3>
            <p className="text-gray-600">لم ينشر هذا المستخدم أي منشورات بعد</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {posts.map((post) => (
              <div key={post._id} className="bg-gray-50 rounded-xl p-4">
                {post.mediaUrl && (
                  <div className="mb-3">
                    {post.type === "image" && (
                      <img
                        src={post.mediaUrl}
                        alt="Post content"
                        className="w-full h-32 object-cover rounded-lg"
                      />
                    )}
                    {post.type === "video" && (
                      <video
                        src={post.mediaUrl}
                        className="w-full h-32 object-cover rounded-lg"
                        controls
                      />
                    )}
                  </div>
                )}
                
                <p className="text-gray-800 text-sm line-clamp-3 mb-2">{post.content}</p>
                
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span>{post.likes?.length || 0} إعجاب</span>
                  <span>{new Date(post._creationTime).toLocaleDateString('ar')}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
