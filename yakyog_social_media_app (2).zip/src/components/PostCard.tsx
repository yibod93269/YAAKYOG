import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";
import { Id } from "../../convex/_generated/dataModel";

interface PostCardProps {
  post: any;
  onUserClick?: (userId: Id<"users">) => void;
}

export function PostCard({ post, onUserClick }: PostCardProps) {
  const [showImageModal, setShowImageModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showVideoPlayer, setShowVideoPlayer] = useState(false);

  const likePost = useMutation(api.posts.likePost);
  const deletePost = useMutation(api.posts.deletePost);
  const sharePost = useMutation(api.posts.sharePost);
  const currentUser = useQuery(api.profiles.getProfile, {});
  const isAdmin = useQuery(api.admin.isAdmin) || false;

  const isLiked = post.likes?.includes(currentUser?.userId);
  const canDelete = post.author?.userId === currentUser?.userId || isAdmin;

  const handleLike = async () => {
    try {
      await likePost({ postId: post._id });
    } catch (error) {
      toast.error("حدث خطأ أثناء الإعجاب");
    }
  };

  const handleDelete = async () => {
    if (confirm("هل أنت متأكد من حذف هذا المنشور؟")) {
      try {
        await deletePost({ postId: post._id });
        toast.success("تم حذف المنشور بنجاح");
      } catch (error) {
        toast.error("حدث خطأ أثناء حذف المنشور");
      }
    }
  };

  const handleShare = async () => {
    try {
      await sharePost({ postId: post._id });
      toast.success("تم مشاركة المنشور");
      setShowShareModal(false);
    } catch (error) {
      toast.error("حدث خطأ أثناء المشاركة");
    }
  };

  const getPostTypeIcon = () => {
    if (post.isYogo) return "🎯";
    switch (post.type) {
      case "image": return "🖼️";
      case "video": return "🎥";
      case "story": return "📖";
      default: return "📝";
    }
  };

  const getPrivacyIcon = () => {
    return post.privacy === "public" ? "🌍" : "👥";
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      {/* Post Header */}
      <div className="p-4 flex items-center justify-between">
        <div 
          className="flex items-center space-x-3 space-x-reverse cursor-pointer"
          onClick={() => onUserClick?.(post.author?.userId)}
        >
          <div className="relative">
            {post.author?.avatarUrl ? (
              <img
                src={post.author.avatarUrl}
                alt={`${post.author.firstName} ${post.author.lastName}`}
                className="w-12 h-12 rounded-full object-cover"
              />
            ) : (
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold">
                  {post.author?.firstName[0]}{post.author?.lastName[0]}
                </span>
              </div>
            )}
            <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${
              post.author?.isOnline ? "bg-green-500" : "bg-red-500"
            }`}></div>
          </div>
          
          <div className="flex-1">
            <div className="flex items-center space-x-2 space-x-reverse">
              <h3 className="font-semibold text-gray-800">
                {post.author?.firstName} {post.author?.lastName}
              </h3>
              {post.author?.isVerified && (
                <span className="text-blue-500">✓</span>
              )}
              <span className="text-lg">{getPostTypeIcon()}</span>
              <span className="text-sm">{getPrivacyIcon()}</span>
            </div>
            <p className="text-sm text-gray-600">
              {formatDistanceToNow(new Date(post._creationTime), {
                addSuffix: true,
                locale: ar,
              })}
            </p>
          </div>
        </div>

        {canDelete && (
          <button
            onClick={handleDelete}
            className="text-red-500 hover:text-red-700 p-2 rounded-full hover:bg-red-50 transition-colors"
          >
            🗑️
          </button>
        )}
      </div>

      {/* Post Content */}
      <div className="px-4 pb-3">
        <p className="text-gray-800 mb-3">{post.content}</p>
        
        {/* Media Content */}
        {post.mediaUrl && (
          <div className="mb-3">
            {post.type === "image" && (
              <img
                src={post.mediaUrl}
                alt="Post content"
                className="w-full h-64 object-cover rounded-xl cursor-pointer hover:opacity-95 transition-opacity"
                onClick={() => setShowImageModal(true)}
              />
            )}
            
            {post.type === "video" && (
              <div className="relative">
                <video
                  src={post.mediaUrl}
                  className="w-full h-64 object-cover rounded-xl"
                  controls={showVideoPlayer}
                  poster={post.mediaUrl}
                />
                {!showVideoPlayer && (
                  <button
                    onClick={() => setShowVideoPlayer(true)}
                    className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30 rounded-xl hover:bg-opacity-40 transition-all"
                  >
                    <div className="w-16 h-16 bg-white bg-opacity-90 rounded-full flex items-center justify-center">
                      <span className="text-2xl">▶️</span>
                    </div>
                  </button>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Post Actions */}
      <div className="px-4 py-3 border-t border-gray-100 flex items-center justify-between">
        <div className="flex items-center space-x-6 space-x-reverse">
          <button
            onClick={handleLike}
            className={`flex items-center space-x-2 space-x-reverse transition-colors ${
              isLiked ? "text-red-500" : "text-gray-600 hover:text-red-500"
            }`}
          >
            <span className="text-xl">{isLiked ? "❤️" : "🤍"}</span>
            <span className="text-sm font-medium">{post.likes?.length || 0}</span>
          </button>

          <button
            onClick={() => setShowShareModal(true)}
            className="flex items-center space-x-2 space-x-reverse text-gray-600 hover:text-blue-500 transition-colors"
          >
            <span className="text-xl">📤</span>
            <span className="text-sm font-medium">{post.shares?.length || 0}</span>
          </button>

          <button className="flex items-center space-x-2 space-x-reverse text-gray-600 hover:text-green-500 transition-colors">
            <span className="text-xl">💬</span>
            <span className="text-sm font-medium">تعليق</span>
          </button>
        </div>

        {post.isYogo && (
          <div className="flex items-center space-x-2 space-x-reverse">
            <span className="text-sm font-medium text-blue-600">YOGO</span>
            <span className="text-blue-500">🎯</span>
          </div>
        )}
      </div>

      {/* Image Modal */}
      {showImageModal && (
        <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4">
          <div className="relative max-w-4xl max-h-full">
            <img
              src={post.mediaUrl}
              alt="Post content"
              className="max-w-full max-h-full object-contain"
            />
            <button
              onClick={() => setShowImageModal(false)}
              className="absolute top-4 right-4 text-white text-2xl hover:text-gray-300"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Share Modal */}
      {showShareModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-gray-800 mb-4">مشاركة المنشور</h3>
            <p className="text-gray-600 mb-6">هل تريد مشاركة هذا المنشور مع أصدقائك؟</p>
            
            <div className="flex space-x-3 space-x-reverse">
              <button
                onClick={() => setShowShareModal(false)}
                className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors"
              >
                إلغاء
              </button>
              <button
                onClick={handleShare}
                className="flex-1 bg-gradient-to-r from-blue-500 to-green-500 text-white px-4 py-3 rounded-xl hover:from-blue-600 hover:to-green-600 transition-all"
              >
                مشاركة
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
