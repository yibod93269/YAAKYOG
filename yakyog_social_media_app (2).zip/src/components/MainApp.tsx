import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Sidebar } from "./Sidebar";
import { Feed } from "./Feed";
import { Profile } from "./Profile";
import { Groups } from "./Groups";
import { Messages } from "./Messages";
import { Notifications } from "./Notifications";
import { Search } from "./Search";
import { CreatePost } from "./CreatePost";
import { Settings } from "./Settings";
import { UserProfile } from "./UserProfile";
import { Id } from "../../convex/_generated/dataModel";

type ActiveTab = "feed" | "profile" | "groups" | "messages" | "notifications" | "search" | "settings" | "userProfile";

export function MainApp() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("feed");
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<Id<"users"> | null>(null);
  
  const updateOnlineStatus = useMutation(api.profiles.updateOnlineStatus);

  const handleUserClick = (userId: Id<"users">) => {
    setSelectedUserId(userId);
    setActiveTab("userProfile");
  };

  useEffect(() => {
    // Set user as online when app loads
    updateOnlineStatus({ isOnline: true });

    // Set user as offline when page unloads
    const handleBeforeUnload = () => {
      updateOnlineStatus({ isOnline: false });
    };

    window.addEventListener("beforeunload", handleBeforeUnload);
    
    // Update online status periodically
    const interval = setInterval(() => {
      updateOnlineStatus({ isOnline: true });
    }, 30000); // Every 30 seconds

    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
      clearInterval(interval);
      updateOnlineStatus({ isOnline: false });
    };
  }, [updateOnlineStatus]);

  const renderContent = () => {
    switch (activeTab) {
      case "feed":
        return <Feed onUserClick={handleUserClick} />;
      case "profile":
        return <Profile />;
      case "groups":
        return <Groups />;
      case "messages":
        return <Messages />;
      case "notifications":
        return <Notifications onUserClick={handleUserClick} />;
      case "search":
        return <Search onUserClick={handleUserClick} />;
      case "settings":
        return <Settings onClose={() => setActiveTab("profile")} />;
      case "userProfile":
        return selectedUserId ? (
          <UserProfile 
            userId={selectedUserId} 
            onBack={() => setActiveTab("feed")}
            onUserClick={handleUserClick}
          />
        ) : <Feed onUserClick={handleUserClick} />;
      default:
        return <Feed onUserClick={handleUserClick} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-1 lg:ml-64">
        <div className="max-w-4xl mx-auto px-4 py-6">
          {renderContent()}
        </div>
      </main>

      {/* Floating Create Post Button */}
      <button
        onClick={() => setShowCreatePost(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center z-40"
      >
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
        </svg>
      </button>

      {/* Create Post Modal */}
      {showCreatePost && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-800">إنشاء منشور جديد</h2>
              <button
                onClick={() => setShowCreatePost(false)}
                className="text-gray-500 hover:text-gray-700 text-2xl"
              >
                ✕
              </button>
            </div>
            <CreatePost />
          </div>
        </div>
      )}
    </div>
  );
}
