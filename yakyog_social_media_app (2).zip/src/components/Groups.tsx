import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function Groups() {
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [showJoinGroup, setShowJoinGroup] = useState(false);
  const [selectedGroup, setSelectedGroup] = useState<any>(null);
  
  const groups = useQuery(api.groups.getUserGroups) || [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">المجموعات</h1>
        <div className="flex space-x-3 space-x-reverse">
          <button
            onClick={() => setShowJoinGroup(true)}
            className="px-4 py-2 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-colors"
          >
            انضمام لمجموعة
          </button>
          <button
            onClick={() => setShowCreateGroup(true)}
            className="px-4 py-2 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-xl hover:from-blue-600 hover:to-green-600 transition-all"
          >
            إنشاء مجموعة
          </button>
        </div>
      </div>

      {groups.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">👥</div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">لا توجد مجموعات</h3>
          <p className="text-gray-600">انضم أو أنشئ مجموعة للبدء</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {groups.map((group) => (
            <div
              key={group._id}
              onClick={() => setSelectedGroup(group)}
              className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow cursor-pointer"
            >
              <div className="flex items-center space-x-4 space-x-reverse mb-4">
                {group.avatarUrl ? (
                  <img
                    src={group.avatarUrl}
                    alt={group.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-semibold">
                      {group.name[0]}
                    </span>
                  </div>
                )}
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-800">{group.name}</h3>
                  <p className="text-sm text-gray-600">{group.memberCount} عضو</p>
                </div>
              </div>
              {group.description && (
                <p className="text-gray-600 text-sm mb-3">{group.description}</p>
              )}
              <div className="flex items-center justify-between text-sm">
                <span className={`px-2 py-1 rounded-full ${
                  group.isPrivate ? "bg-red-100 text-red-600" : "bg-green-100 text-green-600"
                }`}>
                  {group.isPrivate ? "خاصة" : "عامة"}
                </span>
                <span className="text-gray-500">كود: {group.inviteCode}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create Group Modal */}
      {showCreateGroup && (
        <CreateGroupModal onClose={() => setShowCreateGroup(false)} />
      )}

      {/* Join Group Modal */}
      {showJoinGroup && (
        <JoinGroupModal onClose={() => setShowJoinGroup(false)} />
      )}

      {/* Group Chat Modal */}
      {selectedGroup && (
        <GroupChatModal
          group={selectedGroup}
          onClose={() => setSelectedGroup(null)}
        />
      )}
    </div>
  );
}

function CreateGroupModal({ onClose }: { onClose: () => void }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [isPrivate, setIsPrivate] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const createGroup = useMutation(api.groups.createGroup);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setIsLoading(true);
    try {
      await createGroup({
        name: name.trim(),
        description: description.trim() || undefined,
        isPrivate,
      });
      toast.success("تم إنشاء المجموعة بنجاح!");
      onClose();
    } catch (error) {
      toast.error("حدث خطأ أثناء إنشاء المجموعة");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6">
        <h2 className="text-xl font-bold text-gray-800 mb-4">إنشاء مجموعة جديدة</h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              اسم المجموعة
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none"
              placeholder="أدخل اسم المجموعة"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              الوصف (اختياري)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none resize-none"
              placeholder="وصف المجموعة..."
              rows={3}
            />
          </div>

          <div>
            <label className="flex items-center space-x-3 space-x-reverse">
              <input
                type="checkbox"
                checked={isPrivate}
                onChange={(e) => setIsPrivate(e.target.checked)}
                className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500"
              />
              <span className="text-gray-700">مجموعة خاصة</span>
            </label>
          </div>

          <div className="flex space-x-3 space-x-reverse pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isLoading || !name.trim()}
              className="flex-1 bg-gradient-to-r from-blue-500 to-green-500 text-white px-4 py-3 rounded-xl hover:from-blue-600 hover:to-green-600 transition-all disabled:opacity-50"
            >
              {isLoading ? "جاري الإنشاء..." : "إنشاء"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function JoinGroupModal({ onClose }: { onClose: () => void }) {
  const [inviteCode, setInviteCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const joinGroup = useMutation(api.groups.joinGroupByCode);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteCode.trim()) return;

    setIsLoading(true);
    try {
      await joinGroup({ inviteCode: inviteCode.trim().toUpperCase() });
      toast.success("تم الانضمام للمجموعة بنجاح!");
      onClose();
    } catch (error) {
      toast.error("كود الدعوة غير صحيح");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6">
        <h2 className="text-xl font-bold text-gray-800 mb-4">الانضمام لمجموعة</h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              كود الدعوة
            </label>
            <input
              type="text"
              value={inviteCode}
              onChange={(e) => setInviteCode(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none text-center font-mono text-lg"
              placeholder="ABC123"
              required
            />
          </div>

          <div className="flex space-x-3 space-x-reverse pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isLoading || !inviteCode.trim()}
              className="flex-1 bg-gradient-to-r from-blue-500 to-green-500 text-white px-4 py-3 rounded-xl hover:from-blue-600 hover:to-green-600 transition-all disabled:opacity-50"
            >
              {isLoading ? "جاري الانضمام..." : "انضمام"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function GroupChatModal({ group, onClose }: { group: any; onClose: () => void }) {
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const messages = useQuery(api.groups.getGroupMessages, { groupId: group._id }) || [];
  const sendMessage = useMutation(api.groups.sendGroupMessage);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    setIsLoading(true);
    try {
      await sendMessage({
        groupId: group._id,
        content: message.trim(),
        type: "text",
      });
      setMessage("");
    } catch (error) {
      toast.error("حدث خطأ أثناء إرسال الرسالة");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full h-[80vh] flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            {group.avatarUrl ? (
              <img
                src={group.avatarUrl}
                alt={group.name}
                className="w-10 h-10 rounded-full object-cover"
              />
            ) : (
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold">{group.name[0]}</span>
              </div>
            )}
            <div>
              <h3 className="font-semibold text-gray-800">{group.name}</h3>
              <p className="text-sm text-gray-600">{group.memberCount} عضو</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 text-2xl"
          >
            ✕
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => (
            <div key={msg._id} className="flex space-x-3 space-x-reverse">
              <div className="flex-shrink-0">
                {msg.author?.avatarUrl ? (
                  <img
                    src={msg.author.avatarUrl}
                    alt={`${msg.author.firstName} ${msg.author.lastName}`}
                    className="w-8 h-8 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-semibold">
                      {msg.author?.firstName[0]}
                    </span>
                  </div>
                )}
              </div>
              <div className="flex-1">
                <div className="bg-gray-100 rounded-2xl px-4 py-2">
                  <p className="font-semibold text-sm text-gray-800">
                    {msg.author?.firstName} {msg.author?.lastName}
                  </p>
                  <p className="text-gray-700">{msg.content}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Message Input */}
        <form onSubmit={handleSendMessage} className="p-4 border-t border-gray-200">
          <div className="flex space-x-3 space-x-reverse">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="اكتب رسالة..."
              className="flex-1 px-4 py-2 rounded-full border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none"
            />
            <button
              type="submit"
              disabled={!message.trim() || isLoading}
              className="bg-gradient-to-r from-blue-500 to-green-500 text-white px-6 py-2 rounded-full hover:from-blue-600 hover:to-green-600 transition-all disabled:opacity-50"
            >
              إرسال
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
