import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../../convex/_generated/dataModel";

interface SearchProps {
  onUserClick?: (userId: Id<"users">) => void;
}

export function Search({ onUserClick }: SearchProps) {
  const [searchTerm, setSearchTerm] = useState("");

  const searchResults = useQuery(
    api.profiles.searchUsers,
    searchTerm.trim() ? { searchTerm: searchTerm.trim() } : "skip"
  ) || [];

  const followUser = useMutation(api.follows.followUser);
  const unfollowUser = useMutation(api.follows.unfollowUser);

  const handleFollow = async (userId: Id<"users">) => {
    try {
      await followUser({ userId });
      toast.success("تم إرسال طلب المتابعة");
    } catch (error) {
      toast.error("حدث خطأ أثناء إرسال الطلب");
    }
  };

  const handleUnfollow = async (userId: Id<"users">) => {
    try {
      await unfollowUser({ userId });
      toast.success("تم إلغاء المتابعة");
    } catch (error) {
      toast.error("حدث خطأ أثناء إلغاء المتابعة");
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-800 mb-4">البحث عن الأشخاص</h1>
        
        {/* Search Input */}
        <div className="relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="ابحث عن الأشخاص..."
            className="w-full px-4 py-3 pr-12 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none"
          />
          <div className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400">
            🔍
          </div>
        </div>
      </div>

      {/* Search Results */}
      {searchTerm.trim() && (
        <div className="space-y-4">
          {searchResults.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-4xl mb-4">🔍</div>
              <p className="text-gray-600">لا توجد نتائج للبحث "{searchTerm}"</p>
            </div>
          ) : (
            <>
              <h2 className="text-lg font-semibold text-gray-800">
                نتائج البحث ({searchResults.length})
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {searchResults.map((user) => (
                  <UserCard
                    key={user.userId}
                    user={user}
                    onFollow={handleFollow}
                    onUnfollow={handleUnfollow}
                    onViewProfile={onUserClick}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      )}

      {/* Suggestions */}
      {!searchTerm.trim() && (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">👥</div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">اكتشف أشخاص جدد</h3>
          <p className="text-gray-600">ابحث عن الأشخاص باستخدام أسمائهم</p>
        </div>
      )}
    </div>
  );
}

function UserCard({ 
  user, 
  onFollow, 
  onUnfollow, 
  onViewProfile 
}: { 
  user: any; 
  onFollow: (userId: Id<"users">) => void;
  onUnfollow: (userId: Id<"users">) => void;
  onViewProfile?: (userId: Id<"users">) => void;
}) {
  const followStatus = useQuery(api.follows.getFollowStatus, { userId: user.userId });

  const getFollowButton = () => {
    switch (followStatus) {
      case "pending":
        return (
          <button
            onClick={() => onUnfollow(user.userId)}
            className="px-4 py-2 border border-yellow-500 text-yellow-600 rounded-xl hover:bg-yellow-50 transition-colors"
          >
            قيد الانتظار
          </button>
        );
      case "accepted":
        return (
          <button
            onClick={() => onUnfollow(user.userId)}
            className="px-4 py-2 border border-red-500 text-red-600 rounded-xl hover:bg-red-50 transition-colors"
          >
            إلغاء المتابعة
          </button>
        );
      default:
        return (
          <button
            onClick={() => onFollow(user.userId)}
            className="px-4 py-2 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-xl hover:from-blue-600 hover:to-green-600 transition-all"
          >
            متابعة
          </button>
        );
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
      <div className="text-center">
        <div className="relative inline-block mb-4">
          {user.avatarUrl ? (
            <img
              src={user.avatarUrl}
              alt={`${user.firstName} ${user.lastName}`}
              className="w-16 h-16 rounded-full object-cover"
            />
          ) : (
            <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
              <span className="text-white font-semibold text-lg">
                {user.firstName[0]}{user.lastName[0]}
              </span>
            </div>
          )}
          <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-white ${
            user.isOnline ? "bg-green-500" : "bg-red-500"
          }`}></div>
        </div>

        <div className="flex items-center justify-center space-x-2 space-x-reverse mb-1">
          <h3 className="font-semibold text-gray-800">
            {user.firstName} {user.lastName}
          </h3>
          {user.isVerified && (
            <span className="text-blue-500">✓</span>
          )}
        </div>
        
        {user.bio && (
          <p className="text-sm text-gray-600 mb-4 line-clamp-2">{user.bio}</p>
        )}

        <div className="flex space-x-2 space-x-reverse">
          <button
            onClick={() => onViewProfile?.(user.userId)}
            className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors"
          >
            عرض الملف
          </button>
          {getFollowButton()}
        </div>
      </div>
    </div>
  );
}
